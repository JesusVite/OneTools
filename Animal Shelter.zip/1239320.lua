-- 1239320's Lua and Manifest Created by Morrenus
-- Animal Shelter
-- Created: March 03, 2026 at 01:10:57 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 3

-- MAIN APPLICATION
addappid(1239320, 1, "c3856134d170fbc1828a462c93ac295653e8903e8c21b780dafef9f649b9302a") -- Animal Shelter
-- MAIN APP DEPOTS
addappid(1239321, 1, "031692e90ed54217c1b361b298f1d03b582c03b2d3c2ce1d63b6d03e02c7131b") -- Depot 1239321
setManifestid(1239321, "5434897317349036330", 7838643993)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1982080) -- Animal Shelter - Puppies  Kittens DLC
addappid(2267210) -- Animal Shelter - Horse Shelter DLC
addappid(2517260) -- Animal Shelter - Vet Clinic DLC