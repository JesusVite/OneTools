-- 1040200's Lua and Manifest Created by Morrenus
-- Crime Scene Cleaner
-- Created: November 29, 2025 at 07:47:12 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1040200) -- Crime Scene Cleaner
-- MAIN APP DEPOTS
addappid(1040201, 1, "c674332af23f9b6fcc58092e93db43d62fe38a9b004985697e490bde97b45548") -- Depot 1040201
setManifestid(1040201, "932677934820671404", 43048297437)