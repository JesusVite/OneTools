-- 401890's Lua and Manifest Created by Morrenus
-- ARSLAN: THE WARRIORS OF LEGEND
-- Created: September 28, 2025 at 23:09:24 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 16
-- Total DLCs: 15
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(401890) -- ARSLAN: THE WARRIORS OF LEGEND
-- MAIN APP DEPOTS
addappid(401891, 1, "3fdd2578b2e41e70d8c5190739625b6702f8b97fb5ad684a01d41c0075a88a59") -- Arslan Musou Content
setManifestid(401891, "6940433638035187901", 10939066642)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- ARSLAN - Scenario Set 1 (AppID: 427672)
addappid(427672)
addappid(427672, 1, "27a10957e43331a4ebaebfdb60b76464a739d2fa7baf22b2b028e1c3dd6b99b1") -- ARSLAN - Scenario Set 1 - ARSLAN - Scenario Set 1 (427672) Depot
setManifestid(427672, "1660667565661030652", 1055385)
-- ARSLAN - Scenario Set 2 (AppID: 427673)
addappid(427673)
addappid(427673, 1, "9fe8193dca3520a819344863a60d25af9c386ea9a83c3a0796087665fe283349") -- ARSLAN - Scenario Set 2 - ARSLAN - Scenario Set 2 (427673) Depot
setManifestid(427673, "1867069061480724383", 1091221)
-- ARSLAN - Daryun Costume  Weapon (AppID: 427674)
addappid(427674)
addappid(427674, 1, "89c1114c35ba7a72891d77a734ee7025128e83c6647ff17e0303bbe298ba4bf1") -- ARSLAN - Daryun Costume  Weapon - ARSLAN - Daryun Costume & Weapon (427674) Depot
setManifestid(427674, "3427503522025744570", 13607168)
-- ARSLAN - Wall Paper Set 1 (AppID: 427675)
addappid(427675)
addappid(427675, 1, "8e689d7edefa0058b4f19d274f8d377cbbf4c33914e98fb5541a0414a47fcea8") -- ARSLAN - Wall Paper Set 1 - ARSLAN - Wall Paper Set 1 (427675) Depot
setManifestid(427675, "915688173979350695", 18371200)
-- ARSLAN - Original Costume Set 1 (AppID: 427676)
addappid(427676)
addappid(427676, 1, "2f6ce0a5428d79e184fed40484f0256ef6a396de68a9c5608e972466d3e95370") -- ARSLAN - Original Costume Set 1 - ARSLAN - Original Costume Set 1 (427676) Depot
setManifestid(427676, "2634780684021222601", 185376496)
-- ARSLAN - Wall Paper Set 2 (AppID: 427677)
addappid(427677)
addappid(427677, 1, "ff9158445df1d2f8511ec9097f94dfa99e4f1c52cc98a4cad49364d4e51752a6") -- ARSLAN - Wall Paper Set 2 - ARSLAN - Wall Paper Set 2 (427677) Depot
setManifestid(427677, "4454573452367693128", 18371248)
-- ARSLAN - Skill Card Set 1 (AppID: 427678)
addappid(427678)
addappid(427678, 1, "48d8243529086f5138b3ecc91edf77f6f68be85824181766adc42509d7a8d266") -- ARSLAN - Skill Card Set 1 - ARSLAN - Skill Card Set 1 (427678) Depot
setManifestid(427678, "8320751379530979241", 25093128)
-- ARSLAN - Scenario Set 3 (AppID: 427679)
addappid(427679)
addappid(427679, 1, "b748f24fadbba22d6993f29f2ee53fdb11081cbd2f6427200500c22fe6a4655d") -- ARSLAN - Scenario Set 3 - ARSLAN - Scenario Set 3 (427679) Depot
setManifestid(427679, "1443103758470414530", 10582321)
-- ARSLAN - Wall Paper Set 3 (AppID: 428560)
addappid(428560)
addappid(428560, 1, "f2c92fb94af9ecb8b574d6a7b59c6ffcba5244b710550aafb79de0def8c5ae3e") -- ARSLAN - Wall Paper Set 3 - ARSLAN - Wall Paper Set 3 (428560) Depot
setManifestid(428560, "1573191960381472944", 18371248)
-- ARSLAN - Skill Card Set 2 (AppID: 428561)
addappid(428561)
addappid(428561, 1, "4b4bd28dbd1e218a31dfc30a3e0f6637e3bd34b9b01b1aade4624cf513d0cc2d") -- ARSLAN - Skill Card Set 2 - ARSLAN - Skill Card Set 2 (428561) Depot
setManifestid(428561, "2130858948312758510", 25093128)
-- ARSLAN - Scenario Set 4 (AppID: 428562)
addappid(428562)
addappid(428562, 1, "6ae4e9bc40beb65cb68888f133b52c36b2217c8983b7ac1f1c1b5dc7a891d90b") -- ARSLAN - Scenario Set 4 - ARSLAN - Scenario Set 4 (428562) Depot
setManifestid(428562, "4641366954777603609", 14402153)
-- ARSLAN - Skill Card Set 3 (AppID: 428563)
addappid(428563)
addappid(428563, 1, "3f44655d744794db04116602257348f9cc58b02cb51756c75f086e5aa23d495c") -- ARSLAN - Skill Card Set 3 - ARSLAN - Skill Card Set 3 (428563) Depot
setManifestid(428563, "6404867827309585869", 25093188)
-- ARSLAN - Scenario Set 5 (AppID: 428564)
addappid(428564)
addappid(428564, 1, "573a2a60f5b6bb52fbc5fc4a50a5cff065f4d4e160d8fa3fd34c19b800018a22") -- ARSLAN - Scenario Set 5 - ARSLAN - Scenario Set 5 (428564) Depot
setManifestid(428564, "6219996913773885974", 11577458)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(427670) -- ARSLAN - GC Online Rsgistration Key
addappid(427671) -- ARSLAN - GC Coin