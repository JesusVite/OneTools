-- 914710's Lua and Manifest Created by Morrenus
-- Cat Quest II
-- Created: November 27, 2025 at 09:28:44 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(914710) -- Cat Quest II
-- MAIN APP DEPOTS
addappid(914711, 1, "7a9034278cc1f859bc64f942f36c04f11d114e9073a512cf40c1e14b12682ea3") -- Cat Quest 2 Content
setManifestid(914711, "4072021986707565750", 515565745)
addappid(914712, 1, "ad0aca2088e999f434a2d10945f92682cb036f2f9e14fa9842d06fd2e8bce7ac") -- Depot 914712
setManifestid(914712, "7106062962175384621", 521912801)