-- 571740's Lua and Manifest Created by Morrenus
-- Golf It!
-- Created: February 19, 2026 at 17:16:52 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 8
-- Total DLCs: 0
-- Shared Depots: 6

-- MAIN APPLICATION
addappid(571740, 1, "6f7f1957bab03721df3c976aa9c9aeb1251016d54961250b81ba3ad53ce06cd1") -- Golf It!
-- MAIN APP DEPOTS
addappid(571741, 1, "d4d913d1500f6fb2f6555dc308aa9d6dc8174a7fc345fec224d964c6ed298e8b") -- Golf It! Content
setManifestid(571741, "6042546679715273348", 16752155108)
addappid(571742, 1, "c035eba8156fad45f156d0941e520d8ba14372c9fd7ecac112734079a9cc6f01") -- "Golf It! - MacOS
setManifestid(571742, "2470269575872971204", 17889302952)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)