-- 871980's Lua and Manifest Created by Morrenus
-- Digimon Survive
-- Created: December 05, 2025 at 11:21:50 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 8
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(871980) -- Digimon Survive
-- MAIN APP DEPOTS
addappid(871981, 1, "f25a7a7ea76f051ede83b59fef4bef825807cdc488dccc8b89d43dd2038981de") -- Depot 871981
setManifestid(871981, "8579617457993104480", 7076465467)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1958820) -- Digimon Survive Extra Monster Guilmon
addappid(1958830) -- Digimon Survive HP Support Equipment
addappid(2000030) -- Digimon Survive SP Support Equipment
addappid(2000031) -- Digimon Survive Defense Support Equipment
addappid(2000032) -- Digimon Survive Light Skill Equipment
addappid(2000033) -- Digimon Survive Dark Skill Equipment
addappid(2005340) -- Digimon Survive Month 1 Bonus Pack
addappid(2005341) -- Digimon Survive Extra Support Equipment Pack