-- 1701520's Lua and Manifest Created by Morrenus
-- Afterimage
-- Created: September 28, 2025 at 21:38:53 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 6
-- Total DLCs: 1
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1701520) -- Afterimage
-- MAIN APP DEPOTS
addappid(1701521, 1, "db0d8a5eed6f71381499903f6250df33d49f9a7f998dc6be20c1ebe04cbf1eee") -- Depot 1701521
setManifestid(1701521, "8679454049825471006", 3975245570)
addappid(1701522, 1, "6315657c5dad11d05c9d412b95960bcf0527d2a273a47a8ab4b5b1bce7ee628a") -- Depot 1701522
setManifestid(1701522, "7246459749534235594", 3975245580)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- .NET 4.6 Redist (Shared from App 228980)
setManifestid(229005, "7992454656023763365", 62009092)
-- DLCS WITH DEDICATED DEPOTS
-- Afterimage Artbook (AppID: 2389760)
addappid(2389760)
addappid(2389760, 1, "82e74a016a0417c1572824dc83213ed03f32f3fc77e63c6d4d1e9911d30a73df") -- Afterimage Artbook - Depot 2389760
setManifestid(2389760, "4049741743724901806", 93191424)