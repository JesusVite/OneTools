-- 222440's Lua and Manifest Created by Morrenus
-- THE KING OF FIGHTERS 2002 UNLIMITED MATCH
-- Created: September 30, 2025 at 23:52:29 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(222440) -- THE KING OF FIGHTERS 2002 UNLIMITED MATCH
-- MAIN APP DEPOTS
addappid(222441, 1, "ecc4bf27f87ee88b4bb037ee5747c78dea710c160d950c9204f19d7e6a8deff6") -- The King of Fighters 2002 Unlimited Match Content
setManifestid(222441, "6025242472875071924", 1631439265)
-- SHARED DEPOTS (from other apps)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 9688647)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)