-- 1812450's Lua and Manifest Created by Morrenus
-- Bellwright
-- Created: March 02, 2026 at 22:15:37 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1812450, 1, "8f8b40d085d301b4784607c3697556ee6166058d1d93f443d119fc10cd265128") -- Bellwright
-- MAIN APP DEPOTS
addappid(1812451, 1, "287e622ba6bcbad4ca8384750d7928d394c05c2377042af90f4d9eb474cba91a") -- Depot 1812451
setManifestid(1812451, "5647198898748381719", 24399953800)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
setManifestid(229007, "4477590687906973371", 117381405)