-- 2114740's Lua and Manifest Created by Morrenus
-- Blasphemous 2
-- Created: October 04, 2025 at 22:45:02 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 2
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2114740) -- Blasphemous 2
-- MAIN APP DEPOTS
addappid(2114741, 1, "bfa23044329db73bff7359d046baad4e5d546333e7c34042a0065de17eb5350e") -- Depot 2114741
setManifestid(2114741, "466708966389785670", 4270984116)
addappid(2114742, 1, "a0950a724a09a3bc1a126e4543d910aafa0e83727704db0fd11745547ea0bd66") -- Depot 2114742
setManifestid(2114742, "8954525284424133301", 13197618)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITH DEDICATED DEPOTS
-- Blasphemous 2 - Digital Artbook (AppID: 2500160)
addappid(2500160)
addappid(2500160, 1, "503b5732abefe07001d4c001350558da4747a61c52562da4882858a9e2be2235") -- Blasphemous 2 - Digital Artbook - Depot 2500160
setManifestid(2500160, "1591885379887391557", 130182835)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2879370) -- Blasphemous 2 - Mea Culpa