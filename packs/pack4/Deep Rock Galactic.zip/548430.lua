-- 548430's Lua and Manifest Created by Morrenus
-- Deep Rock Galactic
-- Created: March 23, 2026 at 15:02:37 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 13
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(548430, 1, "35e74cda02258a1dc29466af2d3c05f2030830981ead0936e3eb6c9d59284e7d") -- Deep Rock Galactic
-- MAIN APP DEPOTS
addappid(548431, 1, "73ef10dc344cb7fb34be23aea35b20fbb2b32b0db50650919c7e3d731e759aad") -- Deep Rock Galactic Content
setManifestid(548431, "920088234560415275", 3872804455)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(801860) -- Deep Rock Galactic - Supporter Upgrade
addappid(1283090) -- Deep Rock Galactic - Dark Future Pack
addappid(1283091) -- Deep Rock Galactic - MegaCorp Pack
addappid(1430610) -- Deep Rock Galactic - Roughneck Pack
addappid(1530640) -- Deep Rock Galactic - Dawn of the Dread Pack
addappid(1797340) -- Deep Rock Galactic - Rival Tech Pack
addappid(1946960) -- Deep Rock Galactic - Robot Rebellion Pack
addappid(2165590) -- Deep Rock Galactic - Biohazard Pack
addappid(2291670) -- Deep Rock Galactic - Supporter II Upgrade
addappid(2416900) -- Deep Rock Galactic - Decontaminator Pack
addappid(2934390) -- Deep Rock Galactic - Order of the Deep Pack
addappid(3481460) -- Deep Rock Galactic - Skullcrusher Pack
addappid(4207910) -- Deep Rock Galactic - Relic Raider Pack