-- 413420's Lua and Manifest Created by Morrenus
-- Danganronpa 2: Goodbye Despair
-- Created: September 29, 2025 at 06:22:40 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 10
-- Total DLCs: 1
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(413420) -- Danganronpa 2: Goodbye Despair
-- MAIN APP DEPOTS
addappid(413421, 1, "65dd2d598e63ea5ac5c2ccd8a31a71ccb73169f4117c991fa40a8d0fa7f02bdb") -- Danganronpa 2: Goodbye Despair Content
setManifestid(413421, "865716286440512742", 4799472209)
addappid(413422, 1, "a315983577505ccbbff926c252bc06912f1487dd68b7cef7f9eb420c5d199944") -- Danganronpa 2: Goodbye Despair Depot (Mac)
setManifestid(413422, "73890315654914570", 6218240831)
addappid(413423, 1, "eda8cf7512bf7cc489c2bfa82878b18813f77f593e926059b5f709cafa6d8fcf") -- Danganronpa 2: Goodbye Despair Depot (Linux)
setManifestid(413423, "4176999508874191731", 4829306855)
addappid(413425, 1, "9e198ebff66a43ab19b0ea470fb54f3d13df1c07c50165ade299b54a3848b44d") -- Danganronpa 2: Goodbye Despair Depot: Additional 1
setManifestid(413425, "3641548101996708686", 1761252518)
addappid(413426, 1, "ac7959cd7d6badec27457439489adf9c8c3803afd22b9ebc331196ded49b3d57") -- Danganronpa 2: Goodbye Despair Depot: Additional 2
setManifestid(413426, "2621488385565004742", 1768733634)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- .NET 3.5 Redist (Shared from App 228980)
setManifestid(229000, "4622705914179893434", 242743889)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- .NET 3.5 Client Profile Redist (Shared from App 228980)
setManifestid(229001, "4049573910112143457", 267964564)
-- DLCS WITH DEDICATED DEPOTS
-- Danganronpa 2 Goodbye Despair Mini-OST (AppID: 453490)
addappid(453490)
addappid(413424, 1, "9477631711d08c528c8b5d021afdac892141f0fdd9228157884aaa2c128862fb") -- Danganronpa 2 Goodbye Despair Mini-OST - Danganronpa 2: Goodbye Despair Soundtrack
setManifestid(413424, "2944879051336645197", 274447098)