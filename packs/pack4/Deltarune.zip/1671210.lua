-- 1671210's Lua and Manifest Created by Morrenus
-- DELTARUNE
-- Created: October 01, 2025 at 13:28:45 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1671210) -- DELTARUNE
-- MAIN APP DEPOTS
addappid(1671212, 1, "d3b68663ee177c37ee1d5cb49de06cbf9d0d81b2b72ffdde18665f6db6c6ed9f") -- Depot 1671212
setManifestid(1671212, "5291565625263756968", 609142167)
addappid(1671213, 1, "06e8fc629b33851989bebbd53c9e8acde2444b4c75fbf43036e586cc4bc6b1a5") -- Depot 1671213
setManifestid(1671213, "667983367427050155", 624276290)