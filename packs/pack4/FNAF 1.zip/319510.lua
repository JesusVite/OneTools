-- 319510's Lua and Manifest Created by Morrenus
-- Five Nights at Freddy's
-- Created: September 29, 2025 at 12:34:30 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(319510) -- Five Nights at Freddy's
-- MAIN APP DEPOTS
addappid(319511, 1, "1c9bdb805e961c88bff8090d7a3047fc4932948393b4a0d0939cc84ccbe542c4") -- Five Nights at Freddy's Content
setManifestid(319511, "685265219366152400", 231442963)