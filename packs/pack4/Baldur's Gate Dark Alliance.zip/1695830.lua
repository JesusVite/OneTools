-- 1695830's Lua and Manifest Created by Morrenus
-- Baldur's Gate: Dark Alliance
-- Created: January 19, 2026 at 17:20:16 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1695830, 1, "e8dd0721823b3b8cffb5f7f22cffaa18526f4bd183161ac084cc87fe7fb402c8") -- Baldur's Gate: Dark Alliance
-- MAIN APP DEPOTS
addappid(1695831, 1, "d1c928327ca3ee9b74a853ef2af83aa2825a74f9af579767ea087b5923114654") -- Depot 1695831
setManifestid(1695831, "416485436300961382", 4147326172)
addappid(1695832, 1, "30c974458cd50876c93a0347670427378419b8674fcd98a70abb5ef63a82853e") -- Depot 1695832
setManifestid(1695832, "7209713130131730277", 4157904164)
addappid(1695833, 1, "8af1a9569ff8dc9e41d69718bc181e6186df08fa267bba3be545119f12fee684") -- Depot 1695833
setManifestid(1695833, "5546799118317339112", 4149407881)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)