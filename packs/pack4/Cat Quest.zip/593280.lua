-- 593280's Lua and Manifest Created by Morrenus
-- Cat Quest
-- Created: February 06, 2026 at 16:19:18 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(593280, 1, "4c7617a10222ddc57eec48b26190858252b4f6abf957dcd1df52372751db474f") -- Cat Quest
-- MAIN APP DEPOTS
addappid(593281, 1, "33130777c4dc3a1691afe38e0202242580e2135bfb239dcd83e50cd18d384687") -- Cat Quest Content
setManifestid(593281, "7871757316108895128", 335815339)
addappid(593282, 1, "ec64f6931d206ba1eb7bb613b54370221e5fc663201ff555d229347949926fea") -- Cat Quest MacOSX
setManifestid(593282, "3171103444950518645", 442256104)