-- 555950's Lua and Manifest Created by Morrenus
-- Danganronpa Another Episode: Ultra Despair Girls
-- Created: September 29, 2025 at 06:22:48 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 5
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(555950) -- Danganronpa Another Episode: Ultra Despair Girls
-- MAIN APP DEPOTS
addappid(555952, 1, "2e9a60957d79f2cc3fbdfcf4b2a852364493e626daef3d3b4f702c24e2d305a0") -- Danganronpa Another Episode: Ultra Despair Girls [EN]
setManifestid(555952, "3451890528442011371", 17178084850)
addappid(555951, 1, "372a12a1d96aa1014642e4fe55b82a77887e22246cf3266402e7096ef3aae5b5") -- Danganronpa Another Episode: Ultra Despair Girls [JP]
setManifestid(555951, "9114703985677743048", 10366845162)
addappid(555953, 1, "3d5b471314018f6a9a16c0d4ec7b98ccb93fbe70bbf4626bf43e60c1323ac4cc") -- Danganronpa Another Episode: Ultra Despair Girls [CH]
setManifestid(555953, "6936498450357279184", 10297770242)
addappid(555954, 1, "021aca3dfcf2206b2a4ed988642fcb09d11eea690e48d4abed4c508493bbfcf3") -- Danganronpa Another Episode: Ultra Despair Girls [HA]
setManifestid(555954, "8421517668918607840", 10276888642)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)