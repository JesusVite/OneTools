-- 597820's Lua and Manifest Created by Morrenus
-- BIOMUTANT
-- Created: September 29, 2025 at 01:07:50 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(597820) -- BIOMUTANT
-- MAIN APP DEPOTS
addappid(597821, 1, "7717c3f61ba02868ba10112406e09176ec739560f33b596b23ddfb0ffd8f4077") -- BIOMUTANT Content
setManifestid(597821, "1886782927441083012", 27106069441)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1549560) -- BIOMUTANT - Mercenary Class