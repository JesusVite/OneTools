-- 250620's Lua and Manifest Created by Morrenus
-- Among the Sleep
-- Created: September 28, 2025 at 22:19:24 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(250620) -- Among the Sleep
-- MAIN APP DEPOTS
addappid(250621, 1, "99f23e5a4e6a5b3bf98fb1887ad157255fa2fb65dce470d44881af234b9bd03c") -- Among the Sleep WIN
setManifestid(250621, "2823269025836482927", 3873294055)
addappid(250622, 1, "467fd89330af4dbee884a07e04b8c4ddf127e4857daf99d9f1170991407da41c") -- Among the Sleep OSX
setManifestid(250622, "3677271463566441469", 3894514829)
addappid(250623, 1, "043d7e9a5b3e0c8bfad4cdce8e1546130cbc954cb40534860708e30a5078cb62") -- Among the Sleep LIN
setManifestid(250623, "1998581894481601779", 3927384024)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(332210) -- Among the Sleep Prologue