-- 746850's Lua and Manifest Created by Morrenus
-- Cloudpunk
-- Created: September 29, 2025 at 04:37:26 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(746850) -- Cloudpunk
-- MAIN APP DEPOTS
addappid(746851, 1, "ed83d35dc6be8e31e1ecfc8c93f64adb695d5079b751e42eb509e0d07542b1cb") -- Cloudpunk Content
setManifestid(746851, "5225699216215765938", 7087768157)
-- DLCS WITH DEDICATED DEPOTS
-- Cloudpunk - City of Ghosts (AppID: 1536370)
addappid(1536370)
addappid(1536370, 1, "f181d094b56122842c212b3b737c55098b03a4ea01b6c80dfd0f12aefc7cdcbd") -- Cloudpunk - City of Ghosts - "Cloudpunk - City of Ghosts"-Depot
setManifestid(1536370, "4444665877262521693", 8597345850)