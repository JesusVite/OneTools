-- 606280's Lua and Manifest Created by Morrenus
-- Darksiders III
-- Created: September 29, 2025 at 06:38:20 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 4
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(606280, 1, "8d7796a4ff91e32d76436b2db523e0dab1cec7b91f36effea02d73d37369de7b") -- Darksiders III
-- MAIN APP DEPOTS
addappid(606281, 1, "1006fea4a0c69e799b0e76c8ac156521a2e813579a945a71ff8810b9880d3d0b") -- Darksiders III Content
setManifestid(606281, "2263395985912720228", 24078046190)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Darksiders III - Digital Extras (AppID: 889900)
addappid(889900)
addtoken(889900, "12223590723704831934")
addappid(889900, 1, "b7145397071d1789e33b19bbb06dd94f643f3a2fb1b2aa62be3925e2c49e2828") -- Darksiders III - Digital Extras - Darksiders III - Digital Extras (889900) Depot
setManifestid(889900, "3840230030307644742", 2174053258)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(889901) -- Darksiders III - Preorder DLC
addtoken(889901, "1054069495649484218")
addappid(889902) -- Darksiders III - The Crucible
addappid(889903) -- Darksiders III - Keepers of the Void