-- 12200's Lua and Manifest Created by Morrenus
-- Bully: Scholarship Edition
-- Created: September 29, 2025 at 02:29:25 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(12200) -- Bully: Scholarship Edition
-- MAIN APP DEPOTS
addappid(12201, 1, "b02e549a49b9318ee8352042cb5cfe08a4d103eb6a7a3526c27e4e6ec86ed57b") -- Bully: Scholarship Edition content
setManifestid(12201, "8414883404224460046", 5329415078)