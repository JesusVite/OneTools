-- 622650's Lua and Manifest Created by Morrenus
-- Bendy and the Ink Machine
-- Created: January 31, 2026 at 01:28:17 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 3

-- MAIN APPLICATION
addappid(622650, 1, "f58eafb060a990ab6117686ded8bc123be6d236154bd32f39f58fdf1a760656b") -- Bendy and the Ink Machine
-- MAIN APP DEPOTS
addappid(622651, 1, "525bb062dc2acf46744d4fbd02044d28bad4f3266fe3c8e42bd6fdd1d2030e97") -- Bendy and the Ink Machine Depot WIN_64
setManifestid(622651, "1835596478707374252", 3335015717)
addappid(622652, 1, "ff3dc383c775b96130d7be30d5b3a0b9d28a8a761f48663a342206e48f58ff0c") -- Bendy and the Ink Machine Depot WIN_32
setManifestid(622652, "6296547213237956680", 3349827041)
addappid(622653, 1, "32f8523448cd804dbdb79f690000a9a39ec66e90f2b4b8db6dee433092a4abf4") -- Bendy and the Ink Machine Depot LINUX
setManifestid(622653, "8875080210494677398", 3555658312)
addappid(622654, 1, "b05fea5e1e495e4c071fee38d3d800ab0c2bc123fbfc9609da2bf49f614ac42e") -- Bendy and the Ink Machine Depot MAC
setManifestid(622654, "779084498159863616", 3431045521)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(622660) -- Bendy and the Ink Machine Chapter Three
addappid(622661) -- Bendy and the Ink Machine Chapter Two
addappid(730000) -- Bendy and the Ink Machine Chapter Four