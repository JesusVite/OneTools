-- 1574820's Lua and Manifest Created by Morrenus
-- Until Then
-- Created: October 01, 2025 at 05:02:13 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1574820) -- Until Then
-- MAIN APP DEPOTS
addappid(1574821, 1, "a195ac176ad8fdc6cae6bceff829cc13231f258d8c2379b96016589c4843d290") -- Depot 1574821
setManifestid(1574821, "276119394460917432", 2333714711)
addappid(1574822, 1, "f2fabb0a6a9c7117f184eeeefd4a73b6471fbefa9c15eb62dd036458885a72ea") -- Depot 1574822
setManifestid(1574822, "110964260897172987", 2364850628)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)