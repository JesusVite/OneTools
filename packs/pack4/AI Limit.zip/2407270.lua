-- 2407270's Lua and Manifest Created by Morrenus
-- AI Limit
-- Created: March 27, 2026 at 07:11:59 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(2407270, 1, "2615d909118b737d77236fb50a3dd435f355cc2190c1a6ad30a54a3bd11955cc") -- AI Limit
-- MAIN APP DEPOTS
addappid(2407271, 1, "7fbec0c07311645df5048184f930dab908082e6a96be2f0814a3159eaa8de5a6") -- Depot 2407271
setManifestid(2407271, "1317719127499751046", 23643442439)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3391010) -- AI LIMIT - Deluxe Edition Upgrade Pack
addappid(3813800) -- AI LIMIT - Eirenes Furnace of War
-- EMPTY DEPOTS (no content on any branch)
-- addappid(3813800) -- Depot 3813800 (empty depot)