-- 2305840's Lua and Manifest Created by Morrenus
-- Cat Quest III
-- Created: November 14, 2025 at 16:01:14 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2305840) -- Cat Quest III
-- MAIN APP DEPOTS
addappid(2305841, 1, "7bf9c3f47228c505c20c83dc23a54cbbca66b316a368aab8094deac72c8f4149") -- Depot 2305841
setManifestid(2305841, "1838255980611316056", 1101535940)
addappid(2305842, 1, "a53bdb0f35b32f2f472a38dde3e9b29c86ed2509203d270cb4271e0f0ba783e0") -- Depot 2305842
setManifestid(2305842, "5239264532925272611", 1118084325)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITH DEDICATED DEPOTS
-- Cat Quest III The World of Cat Quest Artbook (AppID: 3126830)
addappid(3126830)
addappid(3126830, 1, "2fbc72271a2d3dd17d70b1d956e5e947e84eda431bc4b8cdf67768636b414880") -- Cat Quest III The World of Cat Quest Artbook - Depot 3126830
setManifestid(3126830, "105293413303831502", 277782304)