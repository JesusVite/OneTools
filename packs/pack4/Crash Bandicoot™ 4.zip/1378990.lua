-- 1378990's Lua and Manifest Created by Morrenus
-- Crash Bandicoot™ 4: It’s About Time
-- Created: September 29, 2025 at 05:29:32 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1378990) -- Crash Bandicoot™ 4: It’s About Time
-- MAIN APP DEPOTS
addappid(1378991, 1, "f50ac282f4e8cd6aa1b2477faf75a2d4ac2257737e16ccc8c08533eed66df9c9") -- Depot 1378991
setManifestid(1378991, "6531755016801697470", 73440520)
addappid(1378992, 1, "0472c66839b11731f139af60a48c4d4295051038aa705924072f4f5931162592") -- Depot 1378992
setManifestid(1378992, "7776315403696891647", 25103393008)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)