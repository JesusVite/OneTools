-- 1809540's Lua and Manifest Created by Morrenus
-- Nine Sols
-- Created: January 03, 2026 at 19:42:29 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(1809540, 1, "6579f7e948e92fa5e2e745f8114d468ce0da84db9b05392996ab61dcf5b7a643") -- Nine Sols
-- MAIN APP DEPOTS
addappid(1809541, 1, "6c41504f601faddc7ec40aff4688b9ee9e34c37f2ab46b882880cbcc76a8eb40") -- Depot 1809541
setManifestid(1809541, "4170341253080557508", 6574057085)
addappid(1809542, 1, "39cff11ed94d5fb43612916d75ca9d971b35caeca4fa3bda91610e1118927ec3") -- Depot 1809542
setManifestid(1809542, "6968920301698375133", 6602043922)
-- DLCS WITH DEDICATED DEPOTS
-- Nine Sols Art Book (AppID: 3362590)
addappid(3362590)
addappid(3362590, 1, "8393593da990f6cd827af13ecb9d42c653dabc0101e53dd927e7e55ae2fa4aa1") -- Nine Sols Art Book - Depot 3362590
setManifestid(3362590, "2032132760684014067", 736983358)
addappid(3362591, 1, "0d84cc89dc3f66b203521c09e53075478305ba8702859948d892ba9c3bf0d9d0") -- Nine Sols Art Book - Depot 3362591
setManifestid(3362591, "5837835346821903939", 736983358)