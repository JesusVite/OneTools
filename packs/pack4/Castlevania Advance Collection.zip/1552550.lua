-- 1552550's Lua and Manifest Created by Morrenus
-- Castlevania Advance Collection
-- Created: September 29, 2025 at 03:29:56 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1552550) -- Castlevania Advance Collection
-- MAIN APP DEPOTS
addappid(1552551, 1, "d24eab04f7b33d4268a45d0542c108b481464e503120245df2cb853a256c1928") -- Depot 1552551
setManifestid(1552551, "8609910394922333285", 511071821)