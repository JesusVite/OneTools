-- 955050's Lua and Manifest Created by Morrenus
-- Bright Memory
-- Created: September 29, 2025 at 02:15:57 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 5
-- Total DLCs: 0
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(955050) -- Bright Memory
-- MAIN APP DEPOTS
addappid(955054, 1, "a47e6f05e75feb7e74364cd96a700ce849d593a03f8a46f07ea0e39d61c9ee88") -- Bright Memory（Any language）
setManifestid(955054, "1065074710867961592", 4394973024)
-- SHARED DEPOTS (from other apps)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
setManifestid(229004, "5220958916987797232", 70000464)