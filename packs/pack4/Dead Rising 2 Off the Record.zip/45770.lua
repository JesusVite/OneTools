-- 45770's Lua and Manifest Created by Morrenus
-- Dead Rising 2: Off the Record
-- Created: September 29, 2025 at 06:53:04 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 7
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(45770) -- Dead Rising 2: Off the Record
-- MAIN APP DEPOTS
addappid(45771, 1, "1329c30bbef699a6fd554ab765f9ce546d162d99b49e49391e738d5a47259820") -- Dead Rising 2 Off the Record Content
setManifestid(45771, "6100148078456722817", 115)
addappid(45779, 1, "8118d6b20ddb4f92ac7095215f84a066cb76eaebe9f43f250f49fbf719808f69") -- Dead Rising 2: Off the Record Depot
setManifestid(45779, "8248067333333462619", 7098686479)
-- SHARED DEPOTS (from other apps)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- VC 2005 Redist (Shared from App 228980)
setManifestid(228981, "7613356809904826842", 5884085)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(45772) -- Dead Rising 2 Off the Record Gamebreaker Skills Pack
addappid(45773) -- Dead Rising 2 Off the Record BBQ Chef Skills Pack
addappid(45774) -- Dead Rising 2 Off the Record COSPLAY Skills Pack
addappid(45775) -- Dead Rising 2 Off the Record Cyborg Skills Pack
addappid(45776) -- Dead Rising 2 Off the Record Firefighter Skills Pack
addappid(45777) -- ValveTestApp45777
addappid(45778) -- ValveTestApp45778