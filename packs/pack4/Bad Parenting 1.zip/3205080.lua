-- 3205080's Lua and Manifest Created by Morrenus
-- Bad Parenting 1: Mr. Red Face
-- Created: September 28, 2025 at 23:57:47 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3205080) -- Bad Parenting 1: Mr. Red Face
-- MAIN APP DEPOTS
addappid(3205081, 1, "0aafcaf23db45ca0d186061b0f4a323f8241469b9e166526250eec6d2bbeef93") -- Depot 3205081
setManifestid(3205081, "3707990341524785188", 227368251)