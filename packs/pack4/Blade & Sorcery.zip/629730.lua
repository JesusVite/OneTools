-- 629730's Lua and Manifest Created by Morrenus
-- Blade & Sorcery
-- Created: March 16, 2026 at 13:19:29 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(629730, 1, "6af014d6ae3c7f3f8ab29feb5cba6c81648c362d451a03d1536e2a65de7302dc") -- Blade & Sorcery
-- MAIN APP DEPOTS
addappid(629731, 1, "d545f9c050f40882240b3a912f0ff28459b1cef3f95099c86c74a67d0a0e1541") -- Sorcering Content
setManifestid(629731, "7602532758400198373", 16106733570)