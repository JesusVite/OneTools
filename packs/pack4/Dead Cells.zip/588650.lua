-- 588650's Lua and Manifest Created by Morrenus
-- Dead Cells
-- Created: September 29, 2025 at 06:49:35 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 5

-- MAIN APPLICATION
addappid(588650, 1, "9dd9ead18fafa93ccb47172cd88174b9348e9fde0db0b6ca4a36283844111f6f") -- Dead Cells
-- MAIN APP DEPOTS
addappid(588651, 1, "b1571411c76b5560172122534e5f36b33665aa1ae5337216fb74816b8c06a9cb") -- Dead Cells Content
setManifestid(588651, "1424459526839357792", 2119693708)
addappid(588653, 1, "2336789903ae91cb11227bcf1b373363713f81c832eac5a009f4a34f0dfbf340") -- Dead Cells Linux Depot
setManifestid(588653, "5814907161645516281", 2106531096)
addappid(588652, 1, "98f088e6b86104bf373ec16bf0eddfc7f5228918b7e4c1dddae39f4ab26b0dd3") -- Dead Cells MacOS Depot
setManifestid(588652, "2808220399414699720", 2107405984)
addappid(588654, 1, "d3869ea6e5650f8be36180bcfab511f05b89d33279c4fbcdcb636c53335585ad") -- Dead Cells Mod Tools Depot
setManifestid(588654, "1964813582676736440", 26451370)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1046440) -- Dead Cells Rise of the Giant
addappid(1204130) -- Dead Cells The Bad Seed
addappid(1451460) -- Dead Cells Fatal Falls
addappid(1580050) -- Dead Cells The Queen and the Sea
addappid(2101430) -- Dead Cells Return to Castlevania