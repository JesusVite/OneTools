-- 262060's Lua and Manifest Created by Morrenus
-- Darkest Dungeon®
-- Created: September 29, 2025 at 06:36:13 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 23
-- Total DLCs: 5
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(262060, 1, "74a1007ed0ae35bd91851091c3748151ab4bf964a3786929e9c9cbce2b9a72af") -- Darkest Dungeon®
-- MAIN APP DEPOTS
addappid(262061, 1, "80ffcb74d1590f74ea3d6bf442f54d2a0d21327bae63d6e0cfdad768c7c7b7c2") -- darkest_dungeon_windows_shared_content
setManifestid(262061, "4583226233085545573", 2258491390)
addappid(262062, 1, "c573ff0fbec6f00c8ff86aafc2085945c6a0b934b6396b0c135574e1326f7470") -- darkest_dungeon_windows_content
setManifestid(262062, "1254432666926761166", 116609982)
addappid(262063, 1, "29e00db53e36359014c7975e1991156a35c28410f92643c66fcab5a98239f741") -- darkest_dungeon_osx_content
setManifestid(262063, "1121378655197193485", 156843401)
addappid(262064, 1, "2658baced519789ef83fa5c378667f2d6fa3e62c1c1901b3bc5d357cee4ecb78") -- darkest_dungeon_osx_data
setManifestid(262064, "7509388801392951012", 2258491390)
addappid(262065, 1, "1ed93be3fc9b6d8911781b16ee38ea20b01a601089cc8ea554a0acb19ef80a1e") -- darkest_dungeon_linux_content
setManifestid(262065, "7106401345272552685", 179166916)
addappid(262066, 1, "5ac9e3783153c138b4fbe2ca2fad3c3fde61883c56b8a4a6945fd186c3503e1c") -- darkest_dungeon_linux_data
setManifestid(262066, "3926805602605884573", 2258491390)
-- SHARED DEPOTS (from other apps)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITH DEDICATED DEPOTS
-- Darkest Dungeon The Musketeer (AppID: 445700)
addappid(445700)
addappid(445700, 1, "f49dbb1bf10058d543c577196757756572d32615971242e63d9a5a945903741b") -- Darkest Dungeon The Musketeer - darkest_dungeon_musketeer_windows_shared_content
setManifestid(445700, "560769545274183569", 19939212)
addappid(445701, 1, "a2f4ee66ab860ba416c504648d2fdc24b25877abed72abc6a80bd5d80db45c58") -- Darkest Dungeon The Musketeer - darkest_dungeon_musketeer_osx_shared_content
setManifestid(445701, "1365831417421820010", 19939212)
addappid(445702, 1, "06f8bafa494c20f0eaa74cfc34a237f907789911f7226d207b719ad12810d075") -- Darkest Dungeon The Musketeer - darkest_dungeon_musketeer_linux_shared_content
setManifestid(445702, "5301635625866171440", 19939212)
-- Darkest Dungeon The Crimson Court (AppID: 580100)
addappid(580100)
addappid(580100, 1, "326ca1f3e2c2a5b128d19b9ea4cb0eeb4dd71767ba4649beb35b4964a2f3036d") -- Darkest Dungeon The Crimson Court - darkest_dungeon_crimson_court_windows_content
setManifestid(580100, "6222557203718607465", 350230829)
addappid(580101, 1, "ee5837a6d587a663372bb57cf2ab4527e8d590470905ab6c252ab2810641e0a4") -- Darkest Dungeon The Crimson Court - darkest_dungeon_crimson_court_osx_content
setManifestid(580101, "1565657565947939877", 350230829)
addappid(580102, 1, "1830572dced421bddf06c78c75d178d4c10185652567a7a527787c8db22fff2f") -- Darkest Dungeon The Crimson Court - darkest_dungeon_crimson_court_linux_content
setManifestid(580102, "3978850777272547237", 350230829)
-- Darkest Dungeon The Shieldbreaker (AppID: 702540)
addappid(702540)
addappid(702540, 1, "a072f106d99256a1419ba3b11cbcfe2b88690ebb337e0013b6658ecf70443c5f") -- Darkest Dungeon The Shieldbreaker - darkest_dungeon_shieldbreaker_windows_content
setManifestid(702540, "5141506331153784611", 40087340)
addappid(702541, 1, "23a51aba543af134313157cd260951b978d7fc9c7324ed2970a3d1a3981b093a") -- Darkest Dungeon The Shieldbreaker - darkest_dungeon_shieldbreaker_osx_content
setManifestid(702541, "2273224435470672990", 40087340)
addappid(702542, 1, "4ede4a6602034a69b581069259516b7e22bfffaa8ef452b07688ecbfa4bfe9b1") -- Darkest Dungeon The Shieldbreaker - darkest_dungeon_shieldbreaker_linux_content
setManifestid(702542, "6448535821289548124", 40087340)
-- Darkest Dungeon The Color of Madness (AppID: 735730)
addappid(735730)
addappid(735730, 1, "5aea239e9d2d39fb207060d004d83521f96e2c2376c7ee3292544057f3953333") -- Darkest Dungeon The Color of Madness - darkest_dungeon_color_of_madness_windows_content
setManifestid(735730, "621686432886124292", 643757447)
addappid(735731, 1, "961483d44b60822f029a8a6f399aa9881c3b10bb551c55fc6cf2ef0907f878fa") -- Darkest Dungeon The Color of Madness - darkest_dungeon_color_of_madness_osx_content
setManifestid(735731, "4790693839981705963", 643757447)
addappid(735732, 1, "ee6a70a5c052a74214bfe1965668567dc83abe1e87647d38c0dc676df1b385e0") -- Darkest Dungeon The Color of Madness - darkest_dungeon_color_of_madness_linux_content
setManifestid(735732, "6684691611074244159", 643757447)
-- Darkest Dungeon The Butchers Circus (AppID: 1117860)
addappid(1117860)
addappid(1117860, 1, "eade86a7d3e1fb1164eb5a1886ae5d93db775162aa411c3744c8a27aee496c9f") -- Darkest Dungeon The Butchers Circus - darkest_dungeon_the_pit_windows_content
setManifestid(1117860, "3265268534229067774", 545430020)
addappid(1117861, 1, "a50099d9d81bd78ea990cdae6108db35cc59dbe777dfca43db5e42c332d5c129") -- Darkest Dungeon The Butchers Circus - darkest_dungeon_the_pit_osx_content
setManifestid(1117861, "7933257625620854203", 545430020)
addappid(1117862, 1, "888d380eaa1cf07630bc75e55d54618a00649f08c5a3309ee49ec839ccc0cff6") -- Darkest Dungeon The Butchers Circus - darkest_dungeon_the_pit_linux_content
setManifestid(1117862, "5402419707475563686", 545430020)