-- 1401730's Lua and Manifest Created by Morrenus
-- Crashlands 2
-- Created: January 19, 2026 at 14:43:11 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 1
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1401730) -- Crashlands 2
-- MAIN APP DEPOTS
addappid(1401731, 1, "9feb5500bb35f27058f1c86e3a465a1f4904b2f5abe5ff891a9928cb702fea64") -- Depot 1401731
setManifestid(1401731, "6987439851379486369", 408409158)
-- SHARED DEPOTS (from other apps)
addappid(3665381, 1, "5081b78d2530d0ce043516c1fead2a7b5e41450f15e5910c1ad20e0e3d8dd28c") -- Depot 3665381 (Shared from App 3665380)
setManifestid(3665381, "6792396351188340778", 120356350)