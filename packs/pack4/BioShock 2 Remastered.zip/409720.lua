-- 409720's Lua and Manifest Created by Morrenus
-- BioShock 2 Remastered
-- Created: September 29, 2025 at 01:08:27 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 7
-- Total DLCs: 1
-- Shared Depots: 5

-- MAIN APPLICATION
addappid(409720) -- BioShock 2 Remastered
-- MAIN APP DEPOTS
addappid(409721, 1, "56e58e17318457e873c36142f228883f76508c0ca1bc36270edf4405d546de48") -- BeachTree2 Content
setManifestid(409721, "1322567444167388333", 21417322317)
addappid(409722, 1, "a6ff58d9629130ba9d51f530f81baa688d8a315ec5a4c987340bd102a8873d66") -- Mac - BioShock 2 Remastered App
setManifestid(409722, "6673445807032681387", 116718045)
addappid(409723, 1, "a52ef043d894dafe4165d50e03b5294853ca2f5274fa12f27b4dc380f97ebf67") -- Mac - BioShock 2 Remastered Content
setManifestid(409723, "4228266964534757187", 20307277317)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(525720) -- Minervas Den Remastered