-- 858810's Lua and Manifest Created by Morrenus
-- Dawn of Man
-- Created: November 08, 2025 at 13:45:12 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(858810, 1, "cab80d4065b0fb0eb10b3003c0f495f81f99b6e7dc75e880a72f0789137ce47c") -- Dawn of Man
-- MAIN APP DEPOTS
addappid(858811, 1, "4d48f5ab34027a5f10f343fe3bc5534b0d98e11096526cdfd5ba1343f242ec56") -- Dawn of Man Depot Windows
setManifestid(858811, "6285443185208500270", 1957346858)
addappid(858812, 1, "0236c27bb148aea7260528d2e2eb2dfd1b0a5e80db2956b7495e802be6806ec5") -- Dawn of Man Depot Mac
setManifestid(858812, "1926294955264028579", 1950455107)