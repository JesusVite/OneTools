-- 570940's Lua and Manifest Created by Morrenus
-- DARK SOULS™: REMASTERED
-- Created: September 29, 2025 at 06:35:29 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(570940) -- DARK SOULS™: REMASTERED
-- MAIN APP DEPOTS
addappid(570941, 1, "e782efcd07a6c765e4393f9b7b6285c09819e62da5f1573e40f15b98303799fe") -- Youka Content
setManifestid(570941, "2900566705832487094", 7316141051)
addappid(570942, 1, "74947c74eb866acac60dc108e9c8144e499da81f312f965cfe46ef6c280afaef") -- Youka_JP
setManifestid(570942, "5866652778102292477", 410731132)
addappid(570943, 1, "b789ea361d9a3e2ff6beb324f2a264fa8db3a49e9ccf390e88332f3850ce5735") -- Youka EXE
setManifestid(570943, "2385633508013979570", 50286344)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)