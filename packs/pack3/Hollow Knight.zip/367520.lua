-- 367520's Lua and Manifest Created by Morrenus
-- Hollow Knight
-- Created: February 05, 2026 at 18:28:19 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(367520, 1, "94a0a4b4c50ce3065ce9d4d21eecfdb8bae52f99b16c4eea1649ebcce9ac2e15") -- Hollow Knight
-- MAIN APP DEPOTS
addappid(367521, 1, "de801b9b61e3385b333259cc0f04d2e5d976c4cb8f933cb859d75a4d0125a2a8") -- Hollow Knight Windows
setManifestid(367521, "4709992615819941531", 5197398400)
addappid(367522, 1, "c7e67c6bf87d7128302920e88b17cb6ee322e69585472cbcd2a3d913c7d3579a") -- Hollow Knight Mac
setManifestid(367522, "4223610335284660861", 5250153345)
addappid(367523, 1, "61dd4c0fd624c81feb31fc22cb61a228c4d8077cf3927e9058f736026d9dd838") -- Hollow Knight Linux
setManifestid(367523, "5850920340624324409", 5207310526)