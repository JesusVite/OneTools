-- 205100's Lua and Manifest Created by Morrenus
-- Dishonored
-- Created: September 29, 2025 at 07:56:36 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 10
-- Total DLCs: 7

-- MAIN APPLICATION
addappid(205100) -- Dishonored
-- MAIN APP DEPOTS
addappid(205101, 1, "42107f3f2d8fde4d980e3de5a3b6a9548497675b97fb5be88e578964c24991ce") -- DepotDishonoredGame
setManifestid(205101, "3682254645125751955", 5638863871)
addappid(205102, 1, "1e60f542dfd33d42eef0d45965f5c7a19a6949eb1ec97f399700dbc3c85d7dc8") -- DepotDishonoredLangINT
setManifestid(205102, "955788823064539748", 795947583)
addappid(205103, 1, "ed518fd42aef448c1043fe291a80632e85207242b8d4d18f7f51a4a80bc644aa") -- DepotDishonoredLangFRA
setManifestid(205103, "652007769989793428", 820132144)
addappid(205104, 1, "0cf761fe1cf22a43fa7daba45af5368cd11e40fd5e5f8cff7a154f2cf7434090") -- DepotDishonoredLangITA
setManifestid(205104, "5584694645485522352", 828645769)
addappid(205105, 1, "a5edbaafa3576d51111b4438ae92e73c92252a0970b1c6ed8367fc7db8a1ce18") -- DepotDishonoredLangDEU
setManifestid(205105, "3894833290655216485", 806192748)
addappid(205106, 1, "f406f5908d05fc3baa1c5655ca150862c08a29163d2e956d45c22ca43a55ef35") -- DepotDishonoredLangESN
setManifestid(205106, "194686839392658586", 840422644)
addappid(205107, 1, "4c832577b21680c03a9dfc8e66a8e7448e5233b9f9037c123be0a7fb36e32dbe") -- DepotDishonoredExecutables
setManifestid(205107, "3090641581836335173", 18448896)
-- DLCS WITH DEDICATED DEPOTS
-- Dishonored Dunwall City Trials DLC (AppID: 208570)
addappid(208570)
addappid(208570, 1, "d5f8adf6db0731cd395883db60b943cf3c83d2d447084a3111822237c1f56fe4") -- Dishonored Dunwall City Trials DLC - DLC1
setManifestid(208570, "4109763437725695359", 1292267223)
-- Dishonored The Knife of Dunwall (AppID: 208575)
addappid(208575)
addappid(208575, 1, "ccddbb489f2ba68ba8ab5239862de740f6bfe8871f1d6336bc9364cbf012dd4c") -- Dishonored The Knife of Dunwall - DLC2
setManifestid(208575, "5118738034433535542", 2621243860)
-- Dishonored The Brigmore Witches (AppID: 212894)
addappid(212894)
addappid(212894, 1, "9db7ad1dd15bd13765ae84a6b4f3a6fb5d6947c4c334781e68f96d244989e52f") -- Dishonored The Brigmore Witches - DLC3
setManifestid(212894, "6290470269679908951", 3647917058)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(212890) -- Dishonored Shadow Rat Pack
addappid(212891) -- Dishonored Backstreet Butcher Pack
addappid(212892) -- Dishonored Arcane Assassin Pack
addappid(212893) -- Dishonored Void Walkers Arsenal