-- 485510's Lua and Manifest Created by Morrenus
-- Nioh: Complete Edition
-- Created: September 30, 2025 at 03:44:20 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 6
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(485510) -- Nioh: Complete Edition
-- MAIN APP DEPOTS
addappid(485511, 1, "eebe92a206180d4e31103c85ffa51ad98d44f2be4b697bbeaf237b4657c589c0") -- Nioh Common Data
setManifestid(485511, "3500435105821266774", 79400728490)
addappid(485512, 1, "eb4221176ff254f8b9987132654da11623fda14bcbd0782398d1a4baf1ec0eea") -- Nioh Application
setManifestid(485512, "6314810000001929748", 57221217)
addappid(485513, 1, "6a157f276514bf77af6aee407eacfab5b423e8b8592238722985697cf2306545") -- Nioh Application JP
setManifestid(485513, "776778844353940279", 57221217)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)