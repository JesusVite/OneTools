-- 204450's Lua and Manifest Created by Morrenus
-- Call of Juarez Gunslinger
-- Created: September 29, 2025 at 03:04:57 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(204450) -- Call of Juarez Gunslinger
-- MAIN APP DEPOTS
addappid(204451, 1, "3d148329ddf232af3fb18f4858b48bb6996f9ad8e772fd2c704514914bf422d9") -- CoJ Gunslinger full version exe
setManifestid(204451, "6466535045316228659", 23199330)
addappid(204452, 1, "8e9a42fdf74eee72bfa07718ed0ae0aef8cb3566eb7493a64f15977ca7683ded") -- Content - demo and full common
setManifestid(204452, "779876568638164487", 2205953421)
addappid(204453, 1, "8831bf46c3566b71a12f27a27e95fd784a2485c1d51d3e4ae59c0b0c58c640b2") -- Content - full specific
setManifestid(204453, "6249518467060031795", 2762578409)
addappid(204454, 1, "707c61aedb78b4c745d9030527750bd9ed00d3004bc8344257ccacf41190b701") -- DLL - demo and full common
setManifestid(204454, "611700607188462372", 1787680)