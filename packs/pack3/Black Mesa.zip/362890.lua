-- 362890's Lua and Manifest Created by Morrenus
-- Black Mesa
-- Created: September 29, 2025 at 01:14:12 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 7
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(362890, 1, "4b7e10266c887ed53367d047d2689b4361f00cd5d51cd85e4f6b01aeef7641bb") -- Black Mesa
-- MAIN APP DEPOTS
addappid(362891, 1, "46ba8e1d09bb724bb5274d7fa497e4acd1186881d41a91857922c979d4f37344") -- Black Mesa Content
setManifestid(362891, "3745641804950828055", 29470113480)
addappid(362892, 1, "1141f7df13dcc852bac94bbe7a7d684903dbb97ef068228782c62ac4f8adae23") -- Black Mesa Linux
setManifestid(362892, "4588672532934012726", 385985588)
addappid(362894, 1, "d7ead84613b380590a839d924354b02e5943f64d6d291045d209b2ba4f72f1c4") -- Black Mesa Windows
setManifestid(362894, "8196368488078724424", 219258341)
addappid(362895, 1, "89498042a0fa6ab71fe0ed1cb35240a02daffe7e8f622856eefa3e46dd87e68d") -- Black Mesa English Language
setManifestid(362895, "5909980735403050706", 912781603)
-- SHARED DEPOTS (from other apps)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)