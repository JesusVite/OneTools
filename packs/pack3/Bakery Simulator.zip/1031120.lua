-- 1031120's Lua and Manifest Created by Morrenus
-- Bakery Simulator
-- Created: September 28, 2025 at 23:59:22 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1031120) -- Bakery Simulator
-- MAIN APP DEPOTS
addappid(1031121, 1, "57e801f7c005d043431cad876ad2f1ba922599948edc89b0719419db4d6b0537") -- Depot 1031121
setManifestid(1031121, "8538481092602836996", 15199853244)