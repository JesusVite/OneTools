-- 216250's Lua and Manifest Created by Morrenus
-- Dead Island Riptide
-- Created: September 29, 2025 at 06:51:21 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 12
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(216250) -- Dead Island Riptide
-- MAIN APP DEPOTS
addappid(216251, 1, "9351f4c622e3ae575e4e3ab100cd8eeae24832b7d777eb7c24f3dbaceca5f918") -- Bloodstorm Content
setManifestid(216251, "8643959554586068787", 6241369962)
addappid(216252, 1, "66bb1d2b99a3c2078474e56c20a822c6ac06c0cf1769c33f6db926cbde611060") -- Depot 216252 English
setManifestid(216252, "1299362251232404838", 1388025)
addappid(216253, 1, "4cbd7f7d152da4a79ea8e6032d9a5d0fc7e81f97b92369d98c64a9b6dfb1644a") -- Depot 216253 French
setManifestid(216253, "5474306527558629747", 1446145)
addappid(216254, 1, "f9879488b12a557188903dd22fa3ed47757b65fcd5b47552433ba2b3c45677d8") -- Depot 216254 Italian
setManifestid(216254, "4373303994699023604", 1400749)
addappid(216255, 1, "a6f72aff41d97e789860ed3f36bde109e483fd7de4d7547d493d5069eb6565a4") -- Depot 216255 German
setManifestid(216255, "6276005663296878998", 1466071)
addappid(216256, 1, "383d0eb76b82e8d50b4df6195f25ab99cfeea424e7976b2af6020442d3335dc4") -- Depot 216256 Spanish
setManifestid(216256, "2795468477061145553", 1383231)
addappid(216257, 1, "62df1dca7c6e34fb89f2ba3a4b18c518c9c72ee8b110540edff9cfbe15168211") -- Depot 216257 Polish
setManifestid(216257, "6759323683420155716", 1450998)
addappid(216258, 1, "0db934d53ab28302749088218dba956b9eb9fdfc591c07b89c2d80cd2d98e12a") -- Depot 216258 Czech
setManifestid(216258, "2290639226039583449", 1431893)
addappid(216259, 1, "4db5a69d3f949dd4251894cab7c2603494c07548cc8d054ad5f43980e6372110") -- Depot 216259 DIR_Binaries
setManifestid(216259, "8156222670820693698", 75772166)
addappid(237331, 1, "fd7d2b20d26caa67b8b214cba3a7fa0f498eb9cbb3ae531e9919c34b256a28b7") -- Dead Island Riptide Russian
setManifestid(237331, "1145617026340247554", 1453309301)
-- DLCS WITH DEDICATED DEPOTS
-- Dead Island Riptide - Fashion Victim DLC (AppID: 228740)
addappid(228740)
addappid(228740, 1, "6810d72681822464ec3a67eab2f1d89c3779f0815f8ad58ea90cd37105ef676e") -- Dead Island Riptide - Fashion Victim DLC - Depot 228740 DLC1
setManifestid(228740, "217353629916874628", 431)
-- Dead Island Riptide - Survivor Pack DLC (AppID: 228750)
addappid(228750)
addappid(228750, 1, "19247cf51ad24dddb1d713d96df7d46fa21af29b46d5ac16bca6bac0451c3529") -- Dead Island Riptide - Survivor Pack DLC - Depot 228750 DLC2
setManifestid(228750, "1499861381398018645", 1271)