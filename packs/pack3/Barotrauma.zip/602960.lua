-- 602960's Lua and Manifest Created by Morrenus
-- Barotrauma
-- Created: December 18, 2025 at 09:29:02 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 1 (1 excluded)

-- MAIN APPLICATION
addappid(602960, 1, "78724f00a8538c7548a770db37d02b6d5872204c12aa66972ddf965bd6b45792") -- Barotrauma
-- MAIN APP DEPOTS
addappid(602961, 1, "9548ba939f90ad1341ef0ea0125642dabf42d425fed0a4a5b2ad3d40a88af1d2") -- Barotrauma Win Content
setManifestid(602961, "8103118664826681813", 1234493661)
addappid(602962, 1, "aa05725821345dfdedd93eaef1f0f4fb6e399b95cffc47dbabf9134a7eeca1d9") -- Barotrauma Linux
setManifestid(602962, "7840295720040737389", 1252906365)
addappid(602963, 1, "9420d15bdd3429b9391b475f1d1c59499535e408b59dcc0053cfa369cdbb8609") -- Barotrauma Mac
setManifestid(602963, "963281378927547178", 1242169796)
-- DLCS WITH DEDICATED DEPOTS
-- Barotrauma - Supporter Pack (AppID: 1197650)
addappid(1197650)
addappid(1197650, 1, "179a1e7986e8029892a8442b25794a7e3e6ca59e33a87f8b00233ab4a8fe5ddb") -- Barotrauma - Supporter Pack - Barotrauma - Supporter Pack
setManifestid(1197650, "4582887644478638575", 437541952)
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(3714450) -- DLC 3714450 (unreleased)