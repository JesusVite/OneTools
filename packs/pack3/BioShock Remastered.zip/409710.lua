-- 409710's Lua and Manifest Created by Morrenus
-- BioShock Remastered
-- Created: September 29, 2025 at 01:08:57 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 7
-- Total DLCs: 0
-- Shared Depots: 5

-- MAIN APPLICATION
addappid(409710) -- BioShock Remastered
-- MAIN APP DEPOTS
addappid(409711, 1, "bd65f2941dcca212b3647a1ef093d35794fba9e1874789af52296830e5753e74") -- BeachTree Content
setManifestid(409711, "2054297745673814910", 22182252517)
addappid(409712, 1, "861974161720d0447dbcaf161218365bb3dade2b264871a9dd9b8a3fb10377e4") -- Mac - BioHD App
setManifestid(409712, "5589255365212164825", 145444012)
addappid(409713, 1, "5726f9ecc0a96c7591d3bcadf845fa8dcfcc84a94b22740f7029a46a64297544") -- Mac - BioHD Data
setManifestid(409713, "4316661907019228653", 26211357320)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)