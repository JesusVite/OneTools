-- 696540's Lua and Manifest Created by Morrenus
-- 60 Second Strike
-- Created: October 02, 2025 at 02:14:26 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(696540) -- 60 Second Strike
-- MAIN APP DEPOTS
addappid(696541, 1, "208c11139e02c80f77c551b9a14aeef8bdbf7e2ad011170336131533a33d9af8") -- 60 Second Strike Content
setManifestid(696541, "6881395108772619839", 802116428)