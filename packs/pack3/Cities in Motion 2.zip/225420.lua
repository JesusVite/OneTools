-- 225420's Lua and Manifest Created by Morrenus
-- Cities in Motion 2
-- Created: September 29, 2025 at 04:12:58 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 6
-- Total DLCs: 13
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(225420) -- Cities in Motion 2
-- MAIN APP DEPOTS
addappid(225421, 1, "c1df3aeed33596e683dcc4db338fdcd508e7c20458b5d9d032fab91b09954e2b") -- Cities in Motion 2 Win
setManifestid(225421, "4581677236353699715", 1244605207)
addappid(225422, 1, "d99b3a9792835e6a35659d8f1a9a3cecf500c7817e228bede84e6daa050174aa") -- Cities in Motion 2 Mac
setManifestid(225422, "3918504536964385104", 1245745589)
addappid(225433, 1, "ada369c1842c7494f70a91617c4b8e9fe7b9934b3b36983f77c9183bd902a2ac") -- Cities in Motion 2 Linux
setManifestid(225433, "6356154911662945427", 1261230904)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Cities in Motion 2 Soundtrack (AppID: 310050)
addappid(310050)
addappid(310050, 1, "6be5670d3aea411e8f49d161f73fd79a40ed1a0be9313eb17844200eee694640") -- Cities in Motion 2 Soundtrack - Cities in Motion 2: Soundtrack (310050) Depot
setManifestid(310050, "7397882445155952804", 152507871)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(225423) -- Modern Collection DLC
addappid(225424) -- Cities in Motion 2 Bus Mania
addappid(225426) -- Cities in Motion 2 Metro Madness
addtoken(225426, "17584836522598674230")
addappid(225428) -- Cities in Motion 2 Wending Waterbuses 
addappid(225429) -- Cities in Motion 2 Trekking Trolleys
addappid(225430) -- Cities in Motion 2 Lofty Landmarks
addappid(225431) -- Cities in Motion 2 - Back to the Past
addappid(225432) -- Cities in Motion 2 - Olden Times
addappid(225434) -- Cities in Motion 2 Marvellous Monorails
addappid(283530) -- Cities in Motion 2 European Cities
addappid(306170) -- Cities in Motion 2 Players Choice Vehicle Pack
addappid(306171) -- Cities in Motion 2 European Vehicle Pack