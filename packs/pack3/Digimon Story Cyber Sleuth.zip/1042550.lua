-- 1042550's Lua and Manifest Created by Morrenus
-- Digimon Story Cyber Sleuth: Complete Edition
-- Created: January 20, 2026 at 10:23:17 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1042550, 1, "0f1bf8ab098f867e21a4e7d60c8e1d19c9d7456048daab8a4c6ee200acacbe63") -- Digimon Story Cyber Sleuth: Complete Edition
-- MAIN APP DEPOTS
addappid(1042551, 1, "bd80c7bd28d5cacbe5cc2dfafa6a9464b0e7fd8e769b04750ed0892ce11a162e") -- Wagashi Content
setManifestid(1042551, "1711281787115726840", 5891325803)
addappid(1042552, 1, "96a03909c7aef73b6e510b6ac8b569f9792d7652e01175a5a374ee275deffda3") -- Wagashi EXE Final
setManifestid(1042552, "6775586209044059578", 13618048)
-- SHARED DEPOTS (from other apps)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1042553) -- Depot 1042553 (empty depot)
-- addappid(1042554) -- Depot 1042554 (empty depot)