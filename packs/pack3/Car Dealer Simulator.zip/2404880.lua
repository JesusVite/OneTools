-- 2404880's Lua and Manifest Created by Morrenus
-- Car Dealer Simulator
-- Created: April 01, 2026 at 11:13:10 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0 (1 excluded)
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2404880) -- Car Dealer Simulator
-- MAIN APP DEPOTS
addappid(2404881, 1, "dd3322cbddd81741e4bd8f3d9d08fbe6ff172e3f5c36fec42e215f6661d3ea4f") -- Depot 2404881
setManifestid(2404881, "1776999888143732383", 22298103189)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(4046960) -- Car Dealer Simulator - Up 2 You DLC (unreleased)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4046960) -- Depot 4046960 (empty depot)