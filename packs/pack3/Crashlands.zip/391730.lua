-- 391730's Lua and Manifest Created by Morrenus
-- Crashlands
-- Created: November 25, 2025 at 22:12:56 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(391730) -- Crashlands
-- MAIN APP DEPOTS
addappid(391731, 1, "31db48045139ccd5e4b431c76c2d9831552e9b3877879501bac6b0ea8130551a") -- Crashlands for Windows
setManifestid(391731, "8455360675739640188", 116871800)
addappid(391732, 1, "42943e1707294ffbb6e5e87b3e3627a37d39edb7b10039a4781119eab9716f96") -- Crashlands for Mac
setManifestid(391732, "5160663558593528303", 99499946)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)