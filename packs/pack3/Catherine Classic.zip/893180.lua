-- 893180's Lua and Manifest Created by Morrenus
-- Catherine Classic
-- Created: September 29, 2025 at 03:35:07 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(893180) -- Catherine Classic
-- MAIN APP DEPOTS
addappid(893181, 1, "fb859cb2119e43c326bcbd6cebcc8295d19dc46bda4c89b1689ebb9a5533470e") -- Gooseberry Content
setManifestid(893181, "1628394218060090425", 13991834576)
addappid(893182, 1, "2bd7675876f35e778037e9749f8696e41f2a2d469b231ac7adae2fecb815fcc6") -- Deluxe Edition Content
setManifestid(893182, "1489518346642283788", 127094832)
-- SHARED DEPOTS (from other apps)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)