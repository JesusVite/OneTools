-- 710920's Lua and Manifest Created by Morrenus
-- Darksiders Genesis
-- Created: September 29, 2025 at 06:37:59 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 5
-- Total DLCs: 1
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(710920) -- Darksiders Genesis
-- MAIN APP DEPOTS
addappid(710921, 1, "0b2f1d1915ac05d7b6e430c1fba60087cbad90ca8c93c9008df1d94255a56974") -- Darksiders Genesis Content
setManifestid(710921, "8204476867223286473", 10795814353)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Darksiders Genesis - Digital Extras (AppID: 1203440)
addappid(1203440)
addappid(1203440, 1, "2d0142227179b2656dbddaf685d3cfb706280ba1bb722a29f356e286b6f4c59d") -- Darksiders Genesis - Digital Extras - Darksiders Genesis - Digital Extras (1203440) Depot
setManifestid(1203440, "6588730063426365532", 219903990)