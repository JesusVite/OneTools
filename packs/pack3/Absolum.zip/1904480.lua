-- 1904480's Lua and Manifest Created by Morrenus
-- Absolum
-- Created: March 25, 2026 at 12:17:19 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1904480, 1, "0af2c99f19603642021fffda7d5d95ac03f6b9b5426776add99de302aee3efb0") -- Absolum
-- MAIN APP DEPOTS
addappid(1904481, 1, "119d51fd44dd8198b1a6c12a73e3943c8587d93e990f15b7453404b51a8ce4f3") -- Depot 1904481
setManifestid(1904481, "5090982148506425057", 4865136440)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)