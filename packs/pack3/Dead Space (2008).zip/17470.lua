-- 17470's Lua and Manifest Created by Morrenus
-- Dead Space (2008)
-- Created: September 29, 2025 at 06:56:43 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 6
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(17470) -- Dead Space (2008)
-- MAIN APP DEPOTS
addappid(17471, 1, "37c09725566a2f37a7e099db99334638a3bd9a5e0baf7d79d67039cab768535c") -- Dead Space content
setManifestid(17471, "2334814020589705387", 7958880149)
addappid(17472, 1, "bb179e217854555d2ad5686797567923b79d9ca2f8bc1cc821327220afa6b493") -- Dead Space English
setManifestid(17472, "4696807564043505398", 5225192000)
addappid(17473, 1, "eb3cbc31e17f7f645f2c9261acdf60aa52f6bdfc4d37d2605bd7e70f6bb48b0c") -- Dead Space French
setManifestid(17473, "4576600954076636304", 5206453794)
addappid(17474, 1, "4592e52066a840fa4fef21406c8b2c6674c8eda00575e8d1e4077770e8d262cb") -- Dead Space German
setManifestid(17474, "1240696795312330974", 5136196168)
addappid(17475, 1, "e6b7525043e7caadea7344e0ef880b3ee706138a5ab04a06d7f769743cb65cde") -- Dead Space Italian
setManifestid(17475, "1757382782543725383", 5643750436)
addappid(17476, 1, "6220e7fb29844d167ad7f4142fecc275decbf522be1b2bfca5afc8f180d83e29") -- Dead Space Spanish
setManifestid(17476, "4237117223104214246", 6161537414)