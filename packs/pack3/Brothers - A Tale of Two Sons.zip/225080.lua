-- 225080's Lua and Manifest Created by Morrenus
-- Brothers - A Tale of Two Sons
-- Created: September 29, 2025 at 02:21:11 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(225080) -- Brothers - A Tale of Two Sons
-- MAIN APP DEPOTS
addappid(225081, 1, "37eed7b9e8cef8298da022f816a11a8660f0f6094291370f5419f4708542baed") -- Brothers - A tale of two sons Content
setManifestid(225081, "6840895873058057436", 1322667962)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- .NET 4.0 Client Profile Redist (Shared from App 228980)
setManifestid(229003, "8740933542064151477", 43001447)