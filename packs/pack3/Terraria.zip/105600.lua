-- 105600's Lua and Manifest Created by Morrenus
-- Terraria
-- Created: February 11, 2026 at 04:10:25 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(105600, 1, "b2e8550a65d11a0766af8031eff5de2f979f958a5343319070008a728cfe9150") -- Terraria
-- MAIN APP DEPOTS
addappid(105601, 1, "612f916fe8230616a9c57a1da6e8ae2b642833ef5074b36be5fa7c8515d7155d") -- TerrariaRelease
setManifestid(105601, "6743406415940378864", 801341816)
addappid(105602, 1, "15da89575c5f9ae52e76cacec4f912f9fb3b4f1c152f88b03a14b9acf1c1a173") -- TerrariaLinux
setManifestid(105602, "5873634102231099686", 828282708)
addappid(105603, 1, "a735ff57e669edad75db38c477a9e732f87fb05c824da7cd842712e07e9e51d9") -- TerrariaMac
setManifestid(105603, "547904485603878112", 854135349)