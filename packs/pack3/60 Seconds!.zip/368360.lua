-- 368360's Lua and Manifest Created by Morrenus
-- 60 Seconds!
-- Created: September 30, 2025 at 17:17:31 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 7
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(368360) -- 60 Seconds!
-- MAIN APP DEPOTS
addappid(368361, 1, "2ae9e0ceea9fa82714b84c935be78ba81079c2a262113051c5fa634a29804699") -- 60 Seconds! Win64
setManifestid(368361, "6075978047945216467", 3759916296)
addappid(368363, 1, "ef8ba55610beb7b64ea12aa6841c7915c109713db9847ec3a3795ff72fdf869e") -- 60 Seconds! Win32
setManifestid(368363, "6065576068917307370", 3750206264)
addappid(368365, 1, "c0a0ee89acc3419ac7476d34852b51ad791eb12e36a43aa07de20ce6ea69b266") -- 60 Seconds! MacOS 32
setManifestid(368365, "2340842001239944030", 3762905699)
addappid(368366, 1, "903fd4f5c27dd32b6d461d027b8068046de105d0d649a47efebb330228e5b95b") -- 60 Seconds! MacOS 64
setManifestid(368366, "4368570733143951820", 3825532127)
addappid(368364, 1, "abebb6eabe4d79da75b4eedd4991ed0c620708feabc16b4106183bcf892583b1") -- 60 Seconds! Linux 32
setManifestid(368364, "6596565914329182381", 3764612306)
addappid(368367, 1, "cbea14a4cdcedfed26d44652dd11dd982ccf368f476804d9fba917b1dc5a819a") -- 60 Seconds! Linux 64
setManifestid(368367, "5771844987335981140", 3816760320)
-- SHARED DEPOTS (from other apps)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- .NET 4.0 Client Profile Redist (Shared from App 228980)
setManifestid(229003, "8740933542064151477", 43001447)