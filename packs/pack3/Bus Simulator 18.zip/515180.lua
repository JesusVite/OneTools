-- 515180's Lua and Manifest Created by Morrenus
-- Bus Simulator 18
-- Created: September 29, 2025 at 02:34:26 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 17
-- Total DLCs: 11
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(515180, 1, "19a82436714ef73738abd3f745d0c3f809cc104d205604d5fe2ba924cb4b0f50") -- Bus Simulator 18
-- MAIN APP DEPOTS
addappid(515181, 1, "e77067dcd3c0631114fffc2a39b84c920418771f7164729e262ee79c60fe7548") -- Bus Simulator 18 Content
setManifestid(515181, "1732550004247021797", 4699697873)
addappid(515182, 1, "5120b61cfe520566e74adaabf078d150df6b1867c66fd8f74850265e89245def") -- Bus Simulator 18 German
setManifestid(515182, "6317373018163509323", 0)
addappid(515183, 1, "216a92d6b9136e9675df040e5d6586ed712b1fb357e911fb1999e4834c9bfe65") -- Bus Simulator 18 English
setManifestid(515183, "7705620443348437836", 0)
addappid(515184, 1, "84849cb4721d8cf0b587d659e91ea0f2cd6f5d1f94a8ea3d22587cdefc5a8c94") -- Bus Simulator 18 French
setManifestid(515184, "6476490784562254424", 0)
addappid(515185, 1, "4b89c83121be134695c53bbde99b7bde31ea83a9a5bdd2781cc46f59d840f072") -- Bus Simulator 18 Japanese
setManifestid(515185, "592769051183752181", 0)
addappid(515186, 1, "58b1ea4df8bf48c08e5b7951204488aadad64e45d3b3e7bed70f269051365daf") -- Bus Simulator 18 Polish
setManifestid(515186, "6773061152464050419", 0)
addappid(515187, 1, "0b31c2be91bdc5cc2092c391c0e1e4ffdf1646accc10d4260ba80e753557f527") -- Bus Simulator 18 Portugese
setManifestid(515187, "3630410731877437255", 0)
addappid(515188, 1, "630321d8ce73e5ded5a29e27451875abbd810b148e57961f0f997264ddf75947") -- Bus Simulator 18 Russian
setManifestid(515188, "2314725712353963148", 0)
addappid(515189, 1, "a7403eb3890066cc0af91be5053763f9fe11856d35a19e66530cc7c6146c8237") -- Bus Simulator 18 Spanish
setManifestid(515189, "3295676884107003978", 0)
addappid(832900, 1, "cf392973933aa8222497749c6a30c911e1249370e493c1d8254295228c68767e") -- Bus Simulator 18 Czech
setManifestid(832900, "7862031734938503366", 0)
addappid(832901, 1, "cfacc95770644dd80257552fa3f6cfdcb39294e30a7bd2779e44d119cc65e5eb") -- Bus Simulator 18 Turkish
setManifestid(832901, "5143269225989993291", 0)
addappid(832902, 1, "b0502b9b4cc1bc2b400a69b52f7e1803fa305500f1e1d3453d00f964755fd656") -- Bus Simulator 18 Simplified Chinese
setManifestid(832902, "6481655882764896395", 0)
addappid(832903, 1, "3da4129e6b1d6ebe0109370c5f7945462770fb11f102a8316acd562c933771b2") -- Bus Simulator 18 Korean
setManifestid(832903, "1968118734004388160", 0)
addappid(832904, 1, "64e7bfdb80a289eec4ab5a0a05fcf4ecb38e5393020485e781089df41e68c78f") -- Bus Simulator 18 Italian
setManifestid(832904, "7694650320827564228", 0)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Bus Simulator 18 - Mercedes-Benz Interior Pack 1 (AppID: 968911)
addappid(968911)
addappid(968911, 1, "3c1a9eca18ea00956f8e9e6da3e7ec2c6ebcb7b9af9eeac76a8193c2365baad2") -- Bus Simulator 18 - Mercedes-Benz Interior Pack 1 - "Bus Simulator 18 - Mercedes-Benz Interior Pack 1 (968911)"-Depot
setManifestid(968911, "2395237961655233336", 0)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(850070) -- Bus Simulator 18 - Mercedes-Benz Interior
addappid(850080) -- Bus Simulator 18 - MAN Interior
addappid(850090) -- Bus Simulator 18 - Setra Interior
addappid(850100) -- Bus Simulator 18 - IVECO Interior
addappid(886910) -- Bus Simulator 18 - Country Skin  Decal Pack
addappid(886920) -- Bus Simulator 18 - MAN Bus Pack 1
addappid(968910) -- Bus Simulator 18 - MAN Interior Pack 1
addappid(1058190) -- Bus Simulator 18 - Official map extension
addappid(1123650) -- Bus Simulator 18 - Mercedes-Benz Bus Pack 1
addappid(1149720) -- Bus Simulator 18 - Setra Bus Pack 1