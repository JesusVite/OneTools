-- 255710's Lua and Manifest Created by Morrenus
-- Cities: Skylines
-- Created: March 17, 2026 at 12:21:12 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 95
-- Total DLCs: 76
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(255710, 1, "624bcd6cc6783aaaf17722fb0bfb8a17b1d687e7b76c32b6f038307e1deab622") -- Cities: Skylines
-- MAIN APP DEPOTS
addappid(255711, 1, "125653faaac1bad58ea92c82059dcbe10705c04cd5c97e847c4f68b535fe24a6") -- Cities: Skylines Windows
setManifestid(255711, "5213761194286305875", 17132208144)
addappid(255712, 1, "8b92cc0e5effe6aae01b10e49408f561ebd6a8b4f72c8d9534758e123eba3464") -- Cities: Skylines OSX
setManifestid(255712, "3003485280776675773", 17157141052)
addappid(255713, 1, "7a309e01d09daf057aee177d1645ffb3233b7199a24da2fe28fbf4cb87ac5c91") -- Cities: Skylines Linux
setManifestid(255713, "1839653557928380668", 17072321437)
addappid(352510, 1, "e65d744bca9d5cb2a7fe1e16d8d3c2f8d4fafc219d4cc7bdd9ef5c03f89157ed") -- Cities: Skylines - Soundtrack (352510) Depot
setManifestid(352510, "7123489600763198871", 296695160)
addappid(352511, 1, "3885ecb5bdd0348394a2b36d74b88c1278f63c4d74a6311ba7dddd93512fbf5f") -- Cities: Skylines - The Architecture Artbook (352511) Depot
setManifestid(352511, "5414751412616420673", 8114536)
addappid(352512, 1, "77fab0114fb10f2f3cd6204ed53b8d88cf04cfa6d37268b3ee99e74aabe4d650") -- Cities: Skylines - The Monuments Booklet (352512) Depot
setManifestid(352512, "3674897373088926940", 4167171)
addappid(355600, 1, "1784a931fcade32b697550d07880b21abfb6c358fce9de3994f1e4af73624357") -- Cities Skylines - Post Cards (355600) Depot
setManifestid(355600, "1631829400747429551", 85982781)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Cities Skylines - Relaxation Station (AppID: 547501)
addappid(547501)
addappid(255714, 1, "7fcfe06a667ea8db815ac5d6f6a085b9356ceb39d648f16ceebc9b2e63d560c4") -- Cities Skylines - Relaxation Station - Cities: Skylines - Station1 Win
setManifestid(255714, "1134142675767592641", 249941202)
addappid(255715, 1, "efb97ce4b64d8acd9db5f3a1b557c202d7dfec9bf50999cef10d3a55d87cc69f") -- Cities Skylines - Relaxation Station - Cities: Skylines - Station1 OSX
setManifestid(255715, "5730005230499338630", 249941202)
addappid(255716, 1, "f40ba8a2adca78fc5f9f7599c3eec84071d768d6526b766009b769bf0832ad92") -- Cities Skylines - Relaxation Station - Cities: Skylines - Station1 Linux
setManifestid(255716, "3369737925930638570", 249941202)
-- Cities Skylines - Concerts (AppID: 614581)
addappid(614581)
addappid(255720, 1, "88efcde6dad72f42df80d041f337294a8eeaf033204d3895c67e1e4674baad96") -- Cities Skylines - Concerts - Cities: Skylines - Event Win
setManifestid(255720, "852385160178766697", 190220952)
addappid(255721, 1, "7b56bead9fac9e4482cd126d78ab0aa8ac769a36e701256d662ab4783ad51c9a") -- Cities Skylines - Concerts - Cities: Skylines - Event OSX
setManifestid(255721, "1625223192604467070", 190220952)
addappid(255722, 1, "a08bb860b36673d01bda6747b5ce305f4158f0e19c5f5b62a6196c58a876ddf3") -- Cities Skylines - Concerts - Cities: Skylines - Event Linux
setManifestid(255722, "6633545179875120363", 190220952)
-- Cities Skylines - Rock City Radio (AppID: 614582)
addappid(614582)
addappid(255717, 1, "3bf4014a381fcaa010ab5c49a3d379f07679456cc8347e79726afdfec8960e60") -- Cities Skylines - Rock City Radio - Cities: Skylines - Station2 Win
setManifestid(255717, "457366953280935037", 221183059)
addappid(255718, 1, "739c9129f0d056259cf7aa4b2cb47c659e1be629725c26923ff1eaea80598de0") -- Cities Skylines - Rock City Radio - Cities: Skylines - Station2 OSX
setManifestid(255718, "1681679388249594316", 221183059)
addappid(255719, 1, "df8111ddb3496994aae7c48f8c40583ecfeb88ad4392b0d41f8f9bef0e384254") -- Cities Skylines - Rock City Radio - Cities: Skylines - Station2 Linux
setManifestid(255719, "1293376866617077330", 221183059)
-- Cities Skylines - Carols, Candles and Candy (AppID: 715192)
addappid(715192)
addappid(255723, 1, "9f5cad514a854a2e69156f6f15be1e71b1cc7d82e534579eb34140ea5cb0752a") -- Cities Skylines - Carols, Candles and Candy - Cities: Skylines - AppID1 Win
setManifestid(255723, "8856600409965711738", 72834749)
addappid(255724, 1, "bc598610a321a7ef1c910fc0e61c93be4318dc79c3d2a5408b0327b38fe9aafe") -- Cities Skylines - Carols, Candles and Candy - Cities: Skylines - AppID1 OSX
setManifestid(255724, "9049674155703089828", 72834749)
addappid(255725, 1, "402bca8a2c3cfe139fdc8f578ec9db295dbd9456854100ff78d5470338493ff8") -- Cities Skylines - Carols, Candles and Candy - Cities: Skylines - AppID1 Linux
setManifestid(255725, "1466405059764001106", 72834749)
-- Cities Skylines - All That Jazz (AppID: 715193)
addappid(715193)
addappid(255726, 1, "d21c408150c7aeee48f009d90f2c8379a482d4b350eac3456e2fd6412798f4f1") -- Cities Skylines - All That Jazz - Cities: Skylines - AppID2 Win
setManifestid(255726, "7459269725805026117", 223923386)
addappid(255727, 1, "971b1dcc1143566aaac2f595e39c5546b43375fe17912502a091f4c937b4c3a3") -- Cities Skylines - All That Jazz - Cities: Skylines - AppID2 OSX
setManifestid(255727, "1570965744844427562", 223923386)
addappid(255728, 1, "d689e0e229b0116834440542e7816f42c501088274d464aa97a2d2171ad58846") -- Cities Skylines - All That Jazz - Cities: Skylines - AppID2 Linux
setManifestid(255728, "2844814335444210186", 223923386)
-- Cities Skylines - Country Road Radio (AppID: 815380)
addappid(815380)
addappid(815381, 1, "73495a33cbedc2742bb3df9b1d1e375a45327ed74dc07fe0c7759d8956895d31") -- Cities Skylines - Country Road Radio - Cities: Skylines - CRR Win
setManifestid(815381, "8853720379753105222", 201798429)
addappid(815382, 1, "a1b4c264baca561a983c412ec79a9f60ad9b8f774e1460388a668cc93bf7cc84") -- Cities Skylines - Country Road Radio - Cities: Skylines - CRR OSX
setManifestid(815382, "5377846149254053641", 201798429)
addappid(815383, 1, "a525a730ef7e286e60e9b8f79fda42a47a234a13b39d603857ff861977598581") -- Cities Skylines - Country Road Radio - Cities: Skylines - CRR Linux
setManifestid(815383, "8287929360916114055", 201798429)
-- Cities Skylines - Synthetic Dawn Radio (AppID: 944070)
addappid(944070)
addappid(944072, 1, "59a3e0bc98713eb0dd79ea422fe08faf9c84d6ab99355efb4e6ef3329cb19382") -- Cities Skylines - Synthetic Dawn Radio - Cities: Skylines - Synthetic Dawn Radio Win
setManifestid(944072, "3712078253560121570", 210627595)
addappid(944073, 1, "a33e252c8cde3a006e1911da3837ad0c4677789aee35e8ec7840d72f47c3f35d") -- Cities Skylines - Synthetic Dawn Radio - Cities: Skylines - Synthetic Dawn Radio OSX
setManifestid(944073, "289915600672015817", 210627595)
addappid(944074, 1, "dd16bb91fb7cc5d9e2c6c6f153f78dfe328c7c7feb35ceef28d72d9d2bbc7bb4") -- Cities Skylines - Synthetic Dawn Radio - Cities: Skylines - Synthetic Dawn Radio Linux
setManifestid(944074, "7722967552608028136", 210627595)
-- Cities Skylines - Deep Focus Radio (AppID: 1065490)
addappid(1065490)
addappid(1065492, 1, "848aa9ffcb484d3439f20b7f3782b81d558045627058dadb34f3b32b9953f216") -- Cities Skylines - Deep Focus Radio - Cities: Skylines - Radio Station 6 Win
setManifestid(1065492, "7466621565301344156", 81524223)
addappid(1065493, 1, "983729d8ce46da5066be88351e48cc2bebc18faa5ca87556b84f1b1be5d5f0b0") -- Cities Skylines - Deep Focus Radio - Cities: Skylines - Radio Station 6 OSX
setManifestid(1065493, "2381763253807829369", 81524223)
addappid(1065494, 1, "1c94923473db6498cffa25830e71363b5a47bf8e8d18578369981addddf9e75f") -- Cities Skylines - Deep Focus Radio - Cities: Skylines - Radio Station 6 Linux
setManifestid(1065494, "5004619621585266912", 81524223)
-- Cities Skylines - Campus Radio (AppID: 1065491)
addappid(1065491)
addappid(1065495, 1, "f2403e96c73ffc6295258faee73faca29fdf99905832f050c6a7d95e51328605") -- Cities Skylines - Campus Radio - Cities: Skylines - Radio Station 7 Win
setManifestid(1065495, "8050933269028306268", 66986440)
addappid(1065496, 1, "4442e0f044aefb9d39ca8f94b0ddc976c3bc663a8609dee4ceb63f8d80cef744") -- Cities Skylines - Campus Radio - Cities: Skylines - Radio Station 7 OSX
setManifestid(1065496, "977353470357514182", 66986440)
addappid(1065497, 1, "6c8597525f45f463539b5cd52aaef115aa38e550115e6786b7a847c06dabfedf") -- Cities Skylines - Campus Radio - Cities: Skylines - Radio Station 7 Linux
setManifestid(1065497, "429213752068640145", 66986440)
-- Cities Skylines - Downtown Radio (AppID: 1148021)
addappid(1148021)
addappid(1148023, 1, "0fd70f29e1bad1179aeebede80845a5fdcb470c102148b7a152d582654eb9750") -- Cities Skylines - Downtown Radio - Cities: Skylines - Chocolate Win
setManifestid(1148023, "1922603953388439803", 69344015)
addappid(1148024, 1, "103ce29a6e5a1fe243ce8f182afa3b717d8b4c06a3b01fc873c754fdcf191182") -- Cities Skylines - Downtown Radio - Cities: Skylines - Chocolate OSX
setManifestid(1148024, "5250545151175553704", 69344015)
addappid(1148025, 1, "182a570f256046e6cffa7d434e853b994a55c0d2d52e9154ba706296540fe625") -- Cities Skylines - Downtown Radio - Cities: Skylines - Chocolate Linux
setManifestid(1148025, "8763813454172900471", 69344015)
-- Cities Skylines - Coast to Coast Radio (AppID: 1196100)
addappid(1196100)
addappid(1196101, 1, "79efe2737c98dfdca6c6eb77cf6d40f1b5e6fe8180b8e7fd5dbbc2dce41192c8") -- Cities Skylines - Coast to Coast Radio - Cities: Skylines - Cookies Win
setManifestid(1196101, "1533764397998152295", 88120692)
addappid(1196102, 1, "52c699b95fa97e1428b9b093d3dca281e69a15db9407a9db13af34e7f3c7da31") -- Cities Skylines - Coast to Coast Radio - Cities: Skylines - Cookies OSX
setManifestid(1196102, "252638573530759748", 88120692)
addappid(1196103, 1, "58e607150aa3b2b834d2a522b9b9f6b2c40003df48f71344bb682352a9257bc3") -- Cities Skylines - Coast to Coast Radio - Cities: Skylines - Cookies Linux
setManifestid(1196103, "8513732796251257640", 88120692)
-- Cities Skylines - Rail Hawk Radio (AppID: 1531472)
addappid(1531472)
addappid(1531474, 1, "c8375e4f2a1e9c97bb94fc0e84f1580a9c8d52003d77871c90886d666316daca") -- Cities Skylines - Rail Hawk Radio - Cities: Skylines - Hawk Win
setManifestid(1531474, "5572428835740911639", 73587269)
addappid(1531475, 1, "3219c75974d126c6f3b7bfebe83942dd6777f90dd26f06756c981d53752e722c") -- Cities Skylines - Rail Hawk Radio - Cities: Skylines - Hawk OSX
setManifestid(1531475, "8768455533806446348", 73587269)
addappid(1531476, 1, "ba2a64170b5f0a69a4dc3103c8171112ba7c0e5934a679fac93953a4a02e890f") -- Cities Skylines - Rail Hawk Radio - Cities: Skylines - Hawk Linux
setManifestid(1531476, "8463337664244095814", 73587269)
-- Cities Skylines - Sunny Breeze Radio (AppID: 1531473)
addappid(1531473)
addappid(1531477, 1, "d32d610aca38424af4f8fee4bdbeccb073cd59cdf7cc612eeb11b8043117fb0e") -- Cities Skylines - Sunny Breeze Radio - Cities: Skylines - Breeze Win
setManifestid(1531477, "7467492160282037449", 71403780)
addappid(1531478, 1, "fd5fba1478a69cbe0d79e6e4859294eda30216770ca70cce7adb91b41561b6e7") -- Cities Skylines - Sunny Breeze Radio - Cities: Skylines - Breeze OSX
setManifestid(1531478, "2785578080942865062", 71403780)
addappid(1531479, 1, "9c24571449bab4e2dadafe53d5de073fbdbde57f7bb36139f5db51dcffa2f477") -- Cities Skylines - Sunny Breeze Radio - Cities: Skylines - Breeze Linux
setManifestid(1531479, "8201500015210171955", 71403780)
-- Cities Skylines - On Air Radio (AppID: 1726383)
addappid(1726383)
addappid(340161, 1, "818cd8e997974337e8ee6f89673a057877eac9e2a6ed95f0d6143362ee7dd7bd") -- Cities Skylines - On Air Radio - Depot 340161
setManifestid(340161, "5520484552045864175", 77547215)
addappid(340162, 1, "460efa99f378cad419a9775fa14f95803e658ec3bc404e517dbb41598187b518") -- Cities Skylines - On Air Radio - Depot 340162
setManifestid(340162, "3206627690239484311", 77547215)
addappid(340163, 1, "b63f0566e265d2cbd7a332decc2f082c97d8ec21edbb647f3884e5ab2593514e") -- Cities Skylines - On Air Radio - Depot 340163
setManifestid(340163, "4848260941466591819", 77547215)
-- Cities Skylines - Calm The Mind Radio (AppID: 1726384)
addappid(1726384)
addappid(340164, 1, "086376a5b651fd3bc70b349385d8ae86a79af9b291ed2c49568d21fdb98840bc") -- Cities Skylines - Calm The Mind Radio - Depot 340164
setManifestid(340164, "6466629528687169258", 68230885)
addappid(340165, 1, "9850fbf3d046d21d99531801ccf703c7fef95586ed743d6cf8747cd81052b17f") -- Cities Skylines - Calm The Mind Radio - Depot 340165
setManifestid(340165, "2872744250934900778", 68230885)
addappid(340166, 1, "98012feffaac08868a749b69ce2ebf753a0816844976d0a092fb7e5f00a741c6") -- Cities Skylines - Calm The Mind Radio - Depot 340166
setManifestid(340166, "4673355229412027265", 68230885)
-- Cities Skylines - Shoreline Radio (AppID: 1992292)
addappid(1992292)
addappid(2008401, 1, "2f14bf7eef76208e86f9d40f795938d73d1dd3d855c47fe05e1a7148b4b97587") -- Cities Skylines - Shoreline Radio - Depot 2008401
setManifestid(2008401, "1998533869551272137", 71499256)
addappid(2008402, 1, "48774954cf4636f06d80f85a0c500d58a92db4cbfa7b966b4a21b1a82107754f") -- Cities Skylines - Shoreline Radio - Depot 2008402
setManifestid(2008402, "1567045058205849095", 71499256)
addappid(2008403, 1, "def7673b7ced9ef6d78c78e8cee04c30cb3824b440b737476202b099d83dd13d") -- Cities Skylines - Shoreline Radio - Depot 2008403
setManifestid(2008403, "9154534354189384600", 71499256)
-- Cities Skylines - Paradise Radio (AppID: 1992293)
addappid(1992293)
addappid(2008404, 1, "52e7b7837cbe203c28e79a0192ac7f62666dcbed476f1c70424905a15af7372a") -- Cities Skylines - Paradise Radio - Depot 2008404
setManifestid(2008404, "86736102625976399", 79413682)
addappid(2008405, 1, "4e583ce4a34f6556ff65046f9f7b0045e4ec7327cd439df768d1d76498ee4ac3") -- Cities Skylines - Paradise Radio - Depot 2008405
setManifestid(2008405, "2932537948125357453", 79413682)
addappid(2008406, 1, "c8cf3bffecbb80fa0b5ecd2f86d61ca3cde14d2637deb85174427d1b6d0fcea9") -- Cities Skylines - Paradise Radio - Depot 2008406
setManifestid(2008406, "3361079888336932391", 79413682)
-- Cities Skylines - K-pop Station (AppID: 2144482)
addappid(2144482)
addappid(2148907, 1, "c286ac283dd5ec1be6fbeb739eae9e8cf5e455ee3b528a75a88ccf7fa8a541ef") -- Cities Skylines - K-pop Station - Depot 2148907
setManifestid(2148907, "8120470507175934519", 65739628)
addappid(2148908, 1, "e2c3a2c280aa3abc3bb54e3e2a5cc44bdbaf7ebd6f9b2d33db4490bda09241f5") -- Cities Skylines - K-pop Station - Depot 2148908
setManifestid(2148908, "7783001386352587933", 65739628)
addappid(2148909, 1, "232f281ce643d46bee52c4c26a34755c7ac3f07e5dec52bf6e67e98f066bfdae") -- Cities Skylines - K-pop Station - Depot 2148909
setManifestid(2148909, "6630697275597168439", 65739628)
-- Cities Skylines - 80s Downtown Beat (AppID: 2144483)
addappid(2144483)
addappid(2144485, 1, "12f2e3b3df395f1a960ca3aacfb7c2a599cdf38f5042c373814c125c970ab478") -- Cities Skylines - 80s Downtown Beat - Depot 2144485
setManifestid(2144485, "8513252047756060296", 83401121)
addappid(2144486, 1, "b23df440e0343cf0de558102d4b698c75841debabbc2c08e4a4c9009f13bb639") -- Cities Skylines - 80s Downtown Beat - Depot 2144486
setManifestid(2144486, "2469817934690770627", 83401121)
addappid(2144487, 1, "3c790f9199071fc6db17dd6ba44e7ee50857ae137f677541d37b8de516101783") -- Cities Skylines - 80s Downtown Beat - Depot 2144487
setManifestid(2144487, "4680798037346379050", 83401121)
-- Cities Skylines - JADIA Radio (AppID: 2148902)
addappid(2148902)
addappid(2246687, 1, "2160b000d84a89444a9c5bab7f0fb473efe4b1878dd359ce03dbcf25b4309c59") -- Cities Skylines - JADIA Radio - Depot 2246687
setManifestid(2246687, "1373411172301195856", 75598963)
addappid(2246688, 1, "9e41f603e07f3a0e86295d0b167f6db69d6c1173519ea69f62571458670d7df3") -- Cities Skylines - JADIA Radio - Depot 2246688
setManifestid(2246688, "6645197653114281669", 75598963)
addappid(2246689, 1, "066889f4238f45a4caeafacdbeb2d9be06bbfa130377f38ed0f8eb60dc1c62fb") -- Cities Skylines - JADIA Radio - Depot 2246689
setManifestid(2246689, "2444029409538258608", 75598963)
-- Cities Skylines - African Vibes (AppID: 2148904)
addappid(2148904)
addappid(2202577, 1, "4421aa852b26f07c6a854a3383c2269f1bba7bbfee7be4246b50bd7488671d72") -- Cities Skylines - African Vibes - Depot 2202577
setManifestid(2202577, "4144655263445449597", 82328895)
addappid(2202578, 1, "997411b2120352e3e2d3dc98f3c33b5ba181455e55863d7d82cb12c780b9d48e") -- Cities Skylines - African Vibes - Depot 2202578
setManifestid(2202578, "6208940419707708490", 82328895)
addappid(2202579, 1, "a5f78347180321e5a187086ae040fe4825752d6c28a07f8bfa64c53c5320766f") -- Cities Skylines - African Vibes - Depot 2202579
setManifestid(2202579, "3641560502914519644", 82328895)
-- Cities Skylines - 80s Movies Tunes (AppID: 2225940)
addappid(2225940)
addappid(2246684, 1, "a918a0c5896046bc645c0b6f36026ed95e6a750f44400faa059e026f92db7e73") -- Cities Skylines - 80s Movies Tunes - Depot 2246684
setManifestid(2246684, "1732877566211567483", 77083033)
addappid(2246685, 1, "cdd4b493ff540d37c1ebd05643690b3cfff66a23418a8dc9cdf14633a0fcd7a9") -- Cities Skylines - 80s Movies Tunes - Depot 2246685
setManifestid(2246685, "3407214347726100319", 77083033)
addappid(2246686, 1, "88c65a20301ce5a07ff63e0bea24342a4b830742ba413f931fbea6f7cefceb8f") -- Cities Skylines - 80s Movies Tunes - Depot 2246686
setManifestid(2246686, "7837292275432688062", 77083033)
-- Cities Skylines - Pop-Punk Radio (AppID: 2225941)
addappid(2225941)
addappid(2225947, 1, "5eabd2d610d49b2c0c719b1f2867691face1d4bceaba1ddb7b8d1bc06546048f") -- Cities Skylines - Pop-Punk Radio - Depot 2225947
setManifestid(2225947, "3619214019239292892", 67399769)
addappid(2225948, 1, "fd6dc7ff944c062ec2f4d63523623e506bcfdfeff14a666537dc27b5634140de") -- Cities Skylines - Pop-Punk Radio - Depot 2225948
setManifestid(2225948, "3416241063231335401", 67399769)
addappid(2225949, 1, "372fa05f8e057205822d14f6cb42668c4af1e6ad2a7554b9b1c40bea9a435820") -- Cities Skylines - Pop-Punk Radio - Depot 2225949
setManifestid(2225949, "638136854516622778", 67399769)
-- Cities Skylines - 90s Pop Radio (AppID: 2313323)
addappid(2313323)
addappid(346793, 1, "c37d34546779a8678346002969cceaa7090df2a327bdd65111153e1c1bd7a66e") -- Cities Skylines - 90s Pop Radio - Depot 346793
setManifestid(346793, "3684945901358027266", 72800546)
addappid(346794, 1, "b28af0a5027bbb4fe2b29122531c42bf77ff3f81710ee0afd77b36592980783c") -- Cities Skylines - 90s Pop Radio - Depot 346794
setManifestid(346794, "6565051707236200585", 72800546)
addappid(346795, 1, "5eb7b5a118eac661102dbe13f2060ab272285b94e3fb051843a493bacddc0e24") -- Cities Skylines - 90s Pop Radio - Depot 346795
setManifestid(346795, "5026599379075052060", 72800546)
-- Cities Skylines - Piano Tunes Radio (AppID: 2313324)
addappid(2313324)
addappid(340167, 1, "b50536032fbcacdafa7ddb24e1abbf272a808e1881991c09518f3e2ddb487a93") -- Cities Skylines - Piano Tunes Radio - Depot 340167
setManifestid(340167, "975431156377932985", 72785968)
addappid(340168, 1, "a09be0e2df8dc1e3facd033bca905caa327bda7463a9e3b5beeb14fe090b925a") -- Cities Skylines - Piano Tunes Radio - Depot 340168
setManifestid(340168, "2157956232779948619", 72785968)
addappid(340169, 1, "f1ab804104a529fe82505d66f5564de74765a68ee01d2cf6f794b6881c068096") -- Cities Skylines - Piano Tunes Radio - Depot 340169
setManifestid(340169, "5561310247596373893", 72785968)
-- Cities Skylines - Alpine Tunes Radio (AppID: 2955890)
addappid(2955890)
addappid(761947, 1, "40e30e7c0ecb3ac9763a0abb4e56e380bb0fee7d0521be8e5de8c7abdb44fe47") -- Cities Skylines - Alpine Tunes Radio - Depot 761947
setManifestid(761947, "1664303724625109494", 194968578)
addappid(761948, 1, "aecb31165cecf3d1c935739ad2765c565d179f2451ff53399ce210820de736dd") -- Cities Skylines - Alpine Tunes Radio - Depot 761948
setManifestid(761948, "6018410841992666675", 194968578)
addappid(761949, 1, "3ed87bc5fca2075331666dde80c712cb5a84d29f2e66728bec8f12f9fe316367") -- Cities Skylines - Alpine Tunes Radio - Depot 761949
setManifestid(761949, "9127907975010876990", 194968578)
-- Cities Skylines - Harvest Harmony (AppID: 2955920)
addappid(2955920)
addappid(346796, 1, "5b219e83029bfa53ed2586ba341bd8813ac71beb497b198d61d00ec6c91e9e47") -- Cities Skylines - Harvest Harmony - Depot 346796
setManifestid(346796, "7959860532735839066", 174326336)
addappid(346797, 1, "dbf8f5cb2b2f1c703af2f187c357b4c069261a71936c7d1a655b70aca0f11d32") -- Cities Skylines - Harvest Harmony - Depot 346797
setManifestid(346797, "5351636751931478212", 174326336)
addappid(346798, 1, "6dc83260866056a1a44a519862d65941625ada38d8bb9e81a3b8effc29b5f43b") -- Cities Skylines - Harvest Harmony - Depot 346798
setManifestid(346798, "4803322028317682612", 174326336)
-- Cities Skylines - Harumi Nights FM (AppID: 3731530)
addappid(3731530)
addappid(3843397, 1, "950239ba804650646547d0cf4e324e2110e870b4e3fb81f17bc327b297da9413") -- Cities Skylines - Harumi Nights FM - Depot 3843397
setManifestid(3843397, "444310323919740212", 166967788)
addappid(3843398, 1, "6e29b97dc9de4120b4956fc57cafa2d2aef3664bc7cbf901672372465803e5d3") -- Cities Skylines - Harumi Nights FM - Depot 3843398
setManifestid(3843398, "4273541822090243374", 166967788)
addappid(3843399, 1, "71e34a128f6048fa14daf4e551573d8f222529f3716b7c605a0e1b53c5e83511") -- Cities Skylines - Harumi Nights FM - Depot 3843399
setManifestid(3843399, "8720591051688177665", 166967788)
-- Cities Skylines - 8 Gear Radio (AppID: 4031160)
addappid(4031160)
addappid(1616458, 1, "3d85fcc861795b2bb0ca5283bc569895f8d753f7a8a4d55d131af549408d4e80") -- Cities Skylines - 8 Gear Radio - Depot 1616458
setManifestid(1616458, "9175086803368134282", 61166263)
addappid(1616459, 1, "06cc873bcf0ba8acc2cad50aadf0909ff262770f9cfaaa299e19301f8b9e45d9") -- Cities Skylines - 8 Gear Radio - Depot 1616459
setManifestid(1616459, "6779695878280318264", 61166263)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(346791) -- Cities Skylines - Deluxe Edition Upgrade Pack
addtoken(346791, "2840039886544960915")
addappid(369150) -- Cities Skylines - After Dark
addappid(420610) -- Cities Skylines - Snowfall
addappid(456200) -- Cities Skylines - Match Day
addappid(515190) -- Cities Skylines - Content Creator Pack Art Deco
addappid(515191) -- Cities Skylines - Natural Disasters
addappid(547500) -- Cities Skylines - Content Creator Pack High-Tech Buildings
addappid(547502) -- Cities Skylines - Mass Transit
addappid(563850) -- Cities Skylines - Pearls From the East
addappid(614580) -- Cities Skylines - Green Cities
addappid(715190) -- Cities Skylines - Content Creator Pack European Suburbia
addappid(715191) -- Cities Skylines - Parklife
addappid(715194) -- Cities Skylines - Industries
addappid(944071) -- Cities Skylines - Campus
addappid(1059820) -- Cities Skylines - Content Creator Pack University City
addappid(1146930) -- Cities Skylines - Sunset Harbor
addappid(1148020) -- Cities Skylines - Content Creator Pack Modern City Center
addappid(1148022) -- Cities Skylines - Content Creator Pack Modern Japan
addappid(1531470) -- Cities Skylines - Content Creator Pack Train Stations
addappid(1531471) -- Cities Skylines - Content Creator Pack Bridges  Piers
addappid(1726380) -- Cities Skylines - Airports
addappid(1726381) -- Cities Skylines - Content Creator Pack Vehicles of the World
addappid(1726382) -- Cities Skylines - Content Creator Pack Map Pack
addappid(1992290) -- Cities Skylines - Content Creator Pack Mid-Century Modern
addappid(1992291) -- Cities Skylines - Content Creator Pack Seaside Resorts
addappid(2008400) -- Cities Skylines - Plazas  Promenades
addappid(2144480) -- Cities Skylines - Content Creator Pack Heart of Korea
addappid(2144481) -- Cities Skylines - Content Creator Pack Skyscrapers
addappid(2148900) -- Cities Skylines - Content Creator Pack Africa in Miniature
addappid(2148901) -- Cities Skylines - Financial Districts
addappid(2148903) -- Cities Skylines - Content Creator Pack Map Pack 2
addappid(2224690) -- Cities Skylines - Content Creator Pack Sports Venues
addappid(2224691) -- Cities Skylines - Content Creator Pack Shopping Malls
addappid(2313320) -- Cities Skylines - Content Creator Pack Brooklyn  Queens
addappid(2313321) -- Cities Skylines - Content Creator Pack Railroads of Japan
addappid(2313322) -- Cities Skylines - Content Creator Pack Industrial Evolution
addappid(2342310) -- Cities Skylines - Hotels  Retreats
addappid(2934300) -- Cities Skylines - Expansion Subscription
addappid(2955870) -- Cities Skylines - Content Creator Pack Mountain Village
addappid(2955880) -- Cities Skylines - Content Creator Pack Map Pack 3
addappid(2955900) -- Cities Skylines - Content Creator Pack Countryside
addappid(2955910) -- Cities Skylines - Content Creator Pack Emerging Downtown
addappid(3731500) -- Cities Skylines - Content Creator Pack Shops of Shibuya
addappid(3731510) -- Cities Skylines - Content Creator Pack Map Pack 4
addappid(4031130) -- Cities Skylines - Race Day
addappid(4031140) -- Cities Skylines - Content Creator Pack Renewed History
addappid(4031150) -- Cities Skylines - Content Creator Pack Iconic Brutalism
-- EMPTY DEPOTS (no content on any branch)
-- addappid(340160) -- Depot 340160 (empty depot)
-- addappid(346790) -- Depot 346790 (empty depot)
-- addappid(346791) -- Depot 346791 (empty depot)
-- addappid(365040) -- Depot 365040 (empty depot)
-- addappid(369150) -- Depot 369150 (empty depot)
-- addappid(420610) -- Depot 420610 (empty depot)
-- addappid(456200) -- Depot 456200 (empty depot)
-- addappid(515190) -- Depot 515190 (empty depot)
-- addappid(515191) -- Depot 515191 (empty depot)
-- addappid(525940) -- Depot 525940 (empty depot)
-- addappid(526610) -- Depot 526610 (empty depot)
-- addappid(526611) -- Depot 526611 (empty depot)
-- addappid(526612) -- Depot 526612 (empty depot)
-- addappid(536610) -- Depot 536610 (empty depot)
-- addappid(547500) -- Depot 547500 (empty depot)
-- addappid(547501) -- Depot 547501 (empty depot)
-- addappid(547502) -- Depot 547502 (empty depot)
-- addappid(563850) -- Depot 563850 (empty depot)
-- addappid(614580) -- Depot 614580 (empty depot)
-- addappid(614581) -- Depot 614581 (empty depot)
-- addappid(614582) -- Depot 614582 (empty depot)
-- addappid(715190) -- Depot 715190 (empty depot)
-- addappid(715191) -- Depot 715191 (empty depot)
-- addappid(715192) -- Depot 715192 (empty depot)
-- addappid(715193) -- Depot 715193 (empty depot)
-- addappid(715194) -- Depot 715194 (empty depot)
-- addappid(815380) -- Depot 815380 (empty depot)
-- addappid(944070) -- Depot 944070 (empty depot)
-- addappid(944071) -- Depot 944071 (empty depot)
-- addappid(1059820) -- Depot 1059820 (empty depot)
-- addappid(1065490) -- Depot 1065490 (empty depot)
-- addappid(1065491) -- Depot 1065491 (empty depot)
-- addappid(1146930) -- Depot 1146930 (empty depot)
-- addappid(1148020) -- Depot 1148020 (empty depot)
-- addappid(1148021) -- Depot 1148021 (empty depot)
-- addappid(1148022) -- Depot 1148022 (empty depot)
-- addappid(1196100) -- Depot 1196100 (empty depot)
-- addappid(1531472) -- Depot 1531472 (empty depot)
-- addappid(1531473) -- Depot 1531473 (empty depot)
-- addappid(1726383) -- Depot 1726383 (empty depot)
-- addappid(1726384) -- Depot 1726384 (empty depot)
-- addappid(1992292) -- Depot 1992292 (empty depot)
-- addappid(1992293) -- Depot 1992293 (empty depot)
-- addappid(2144482) -- Depot 2144482 (empty depot)
-- addappid(2144483) -- Depot 2144483 (empty depot)
-- addappid(2148902) -- Depot 2148902 (empty depot)
-- addappid(2148904) -- Depot 2148904 (empty depot)
-- addappid(2225940) -- Depot 2225940 (empty depot)
-- addappid(2225941) -- Depot 2225941 (empty depot)
-- addappid(2313323) -- Depot 2313323 (empty depot)
-- addappid(2313324) -- Depot 2313324 (empty depot)
-- addappid(2955890) -- Depot 2955890 (empty depot)
-- addappid(2955920) -- Depot 2955920 (empty depot)
-- addappid(3731530) -- Depot 3731530 (empty depot)
-- addappid(4031160) -- Depot 4031160 (empty depot)