-- 108710's Lua and Manifest Created by Morrenus
-- Alan Wake
-- Created: September 28, 2025 at 21:56:14 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 18
-- Total DLCs: 3

-- MAIN APPLICATION
addappid(108710) -- Alan Wake
-- MAIN APP DEPOTS
addappid(108725, 1, "29b03c21ab8aa192c9887499075d79cae9f5e441213f810e74040f13f7eb6650") -- Alan Wake Datas
setManifestid(108725, "1993621679641115397", 3547577277)
addappid(108724, 1, "4fda34d7cdc50d35a4bd100a30a4eb23d47eeab4d13dea76441d57452a574b53") -- Alan Wake Videos
setManifestid(108724, "8702697917673304354", 4425106436)
addappid(108723, 1, "63201370bc616dec6faa824600dabc95a39474dfe1a21040e6b258c415e7ca5a") -- Alan Wake ExesAndShaders
setManifestid(108723, "5060317705156608793", 30033812)
addappid(108712, 1, "76ae76c8e8329d7e8fd7e54145770aefac0d18b853f25fb0ad76139305dc8b43") -- Alan Wake ThirdParty
setManifestid(108712, "901025420359456534", 107391272)
addappid(108714, 1, "58a4933a1cb9cbfc1bfcf97f0e916c407d3ed63d8782afad70bd680451dc7eb4") -- Alan Wake german
setManifestid(108714, "7153105019757630594", 271228922)
addappid(108715, 1, "45ff646c49b2d4adde1631e0444cbc213214883c3357351c7256d3f8a3e732bc") -- Alan Wake tchinese
setManifestid(108715, "8640327155719467447", 10708847)
addappid(108716, 1, "e3bd3cff0ce0749b5c6f782ebd84722d762b0a2fd31504b4e286c47eca1fc68d") -- Alan Wake spanish
setManifestid(108716, "9153511591353296967", 271081674)
addappid(108717, 1, "01fa7167dedeaebdd29cdf423312c0e49d95bfdd0a5b2cd42434f69f3627c505") -- Alan Wake french
setManifestid(108717, "7363828501531477407", 271239122)
addappid(108718, 1, "5cde1de1c5b9bb5accad062487b0fc79c912754fae85cde9bf05926166a50453") -- Alan Wake italian
setManifestid(108718, "4467213347088643931", 270653930)
addappid(108719, 1, "9f0af0dd9b121c271670fbe72725d8b67a2bac55bed1ed6bc1e594a0e0271c3f") -- Alan Wake Japanese
setManifestid(108719, "4247239336910949318", 273148600)
addappid(108720, 1, "3207988014785543a77a0bc7c4a8a9ae9dbbbdd8e2d08249628bce804a19205e") -- Alan Wake koreana
setManifestid(108720, "1973162837400191961", 8900687)
addappid(108721, 1, "ef3742e56ca3cccca4ed1d71d659ed801869915a36b5860dc4ae00d41fe5f1aa") -- Alan Wake Polish
setManifestid(108721, "1797539877300237257", 12775990)
addappid(108722, 1, "b2aa53bb1464a54d8498862bc2e5f59696b27f45b77708968dce407e4ddb7bf7") -- Alan Wake Russian
setManifestid(108722, "2433517643315622897", 12980926)
addappid(108728, 1, "8e002cdf751131259924e7a28965bd025e71690c6328f9f8e57a08f869657239") -- Alan Wake Czech
setManifestid(108728, "8247444636893821162", 10531092)
addappid(108711, 1, "593019a366642176828b47ad2404c961328ad6d50cc1e105624421a5e55f51d7") -- Alan Wake 2020 Fix
setManifestid(108711, "3695390701422947803", 13499209517)
-- DLCS WITH DEDICATED DEPOTS
-- Alan Wake Developer Commentary (AppID: 108726)
addappid(108726)
addappid(108726, 1, "9ebe0fd1145cd3cf70f5c9d95392770d67885c7cb51fd5902a658601b3107d39") -- Alan Wake Developer Commentary - Alan Wake Developer Commentary
setManifestid(108726, "1713738522381113009", 312260861)
-- Alan Wake LatAmSpanish (AppID: 108727)
addappid(108727)
addappid(108727, 1, "9064e7a115fcba0603259c3a8e068ae0cc09239e99a5b3ee8c2342c08a2e9d9a") -- Alan Wake LatAmSpanish - Alan Wake LatAmSpanish
setManifestid(108727, "2106058700918439926", 8075919)
-- Alan Wake Bonus Materials (AppID: 268560)
addappid(268560)
addappid(268560, 1, "bcc6783bed2b3227d8faba2ead3f192aa0de1481bd1d538ac5297174517f4b86") -- Alan Wake Bonus Materials - Alan Wake Bonus Materials (268560) Depot
setManifestid(268560, "6556411015070000727", 3383521631)