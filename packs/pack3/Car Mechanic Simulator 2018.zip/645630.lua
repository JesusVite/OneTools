-- 645630's Lua and Manifest Created by Morrenus
-- Car Mechanic Simulator 2018
-- Created: September 29, 2025 at 03:18:00 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 21
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(645630, 1, "bee9fc3627bb280d5bc55166cf5d7db8786d12c6fbf36f678b86102f7d00b3f8") -- Car Mechanic Simulator 2018
-- MAIN APP DEPOTS
addappid(645631, 1, "73f7f7288bbb1a2ad499ae870ac6bf3174c5e13651f4ff7299c711e9e3458c5b") -- Car Mechanic Simulator 2018 Content
setManifestid(645631, "700572195903310021", 11348245233)
addappid(645632, 1, "c8056b5b3d56a5cef604f29196951d34b791229da6270e256cc72169298b334b") -- Car Mechanic Simulator 2018 Windows Executable
setManifestid(645632, "7578086906418476369", 650752)
addappid(645633, 1, "becf4ef2055c5c50ca14090f22413e8072cc46870cc031d9c8071f393573754c") -- Car Mechanic Simulator 2018 Depot
setManifestid(645633, "1884906362687120154", 11489903925)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(672270) -- Car Mechanic Simulator 2018 - Mazda DLC
addappid(672271) -- Car Mechanic Simulator 2018 - Dodge DLC
addappid(710430) -- Car Mechanic Simulator 2018 - Tuning DLC
addappid(717490) -- Car Mechanic Simulator 2018 - Jeep DLC
addappid(754920) -- Car Mechanic Simulator 2018 - Plymouth DLC
addappid(754921) -- Car Mechanic Simulator 2018 - Pagani DLC
addappid(754922) -- Car Mechanic Simulator 2018 - RAM DLC
addappid(754923) -- Car Mechanic Simulator 2018 - Lotus DLC
addappid(783150) -- Car Mechanic Simulator 2018 - Bentley Remastered DLC
addappid(799950) -- Car Mechanic Simulator 2018 - Garage Customization DLC
addappid(868280) -- Car Mechanic Simulator 2018 - Ford DLC
addappid(947930) -- Car Mechanic Simulator 2018 - Porsche DLC
addappid(987050) -- Car Mechanic Simulator 2018 - Dodge Modern DLC
addappid(1019540) -- Car Mechanic Simulator 2018 - Maserati REMASTERED DLC
addappid(1125210) -- Car Mechanic Simulator 2018 - Rims DLC
addappid(1215050) -- Car Mechanic Simulator 2018 - Mercedes-Benz DLC
addappid(1265620) -- Car Mechanic Simulator 2018 - Chrysler DLC
addappid(1710610) -- Car Mechanic Simulator 2018 - Hot Rod Custom Cars
addappid(1851590) -- Car Mechanic Simulator 2018 - USA CLASSIC 60S DLC
addappid(1851591) -- Car Mechanic Simulator 2018 - Wheeler Dealers DLC
addappid(1966190) -- Car Mechanic Simulator 2018 - Vans  Campers DLC