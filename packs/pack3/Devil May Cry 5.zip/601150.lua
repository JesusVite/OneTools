-- 601150's Lua and Manifest Created by Morrenus
-- Devil May Cry 5
-- Created: September 29, 2025 at 07:36:05 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 35
-- Total DLCs: 31
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(601150) -- Devil May Cry 5
-- MAIN APP DEPOTS
addappid(601151, 1, "8044d37b8d329e3e7d4a9006b3714cf2fab0d9e01f4c52e8bf9de594d7d56616") -- SAG Content
setManifestid(601151, "5034340940015103443", 36243803797)
addappid(601152, 1, "c7b902e53de220fc8e8c2c70865f3715efb354728b674632f29c0a05d0106b49") -- SAG Execution
setManifestid(601152, "37045512487732505", 137749400)
-- SHARED DEPOTS (from other apps)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Devil May Cry 5 - Alt Hero Colors (AppID: 940500)
addappid(940500)
addtoken(940500, "15395713889670263031")
addappid(940500, 1, "db321935bd04473cba18b369e1acd0473cb81e2bb55da69831ad41dcdf53e017") -- Devil May Cry 5 - Alt Hero Colors - Devil May Cry 5 - Alt Hero Colors (940500) デポ
setManifestid(940500, "7413960716303235231", 91)
-- Devil May Cry 5 - Alt Heroine Colors (AppID: 940501)
addappid(940501)
addtoken(940501, "17090740545056484481")
addappid(940501, 1, "28000509908ca2d0497e06d545c29cecfab409c0bb6a5bf751ffc234d12c9857") -- Devil May Cry 5 - Alt Heroine Colors - Devil May Cry 5 - Alt Heroine Colors (940501) デポ
setManifestid(940501, "5229117904072034661", 91)
-- Devil May Cry 5 - Alt Style Rank Announcers (AppID: 941950)
addappid(941950)
addtoken(941950, "11130147552566329976")
addappid(941950, 1, "8146b03fb25b17f21109ba91ea88540806e540385eb7bd6ed55a64f22db3053d") -- Devil May Cry 5 - Alt Style Rank Announcers - Devil May Cry 5 - Alt Style Rank Announcers (941950) デポ
setManifestid(941950, "1733062317174775810", 4728569)
-- Devil May Cry 5 - Alt Title Calls (AppID: 941951)
addappid(941951)
addappid(941951, 1, "b5e89454b9414c94fab3a1237e3c6151e14ec0525878de309d604e30e6d24e2f") -- Devil May Cry 5 - Alt Title Calls - Devil May Cry 5 - Alt Title Calls (941951) デポ
setManifestid(941951, "1793548331382100654", 5941810)
-- Devil May Cry 5 - Live Action Cutscenes (AppID: 941952)
addappid(941952)
addappid(941952, 1, "8dff48be626e1466d5f18f3f928cf632c786a147e8ef01e4cc923f299ae06204") -- Devil May Cry 5 - Live Action Cutscenes - Devil May Cry 5 - Live Action Cutscenes (941952) デポ
setManifestid(941952, "7836766670222491839", 6498014899)
-- Devil May Cry 5 - DMC1 Battle Track 3-Pack (AppID: 941953)
addappid(941953)
addappid(941953, 1, "2483c086da18c77fca6d239e76ae60418ebad0a7fbbe85c43a732bdf63a4f478") -- Devil May Cry 5 - DMC1 Battle Track 3-Pack - Devil May Cry 5 - DMC1 Battle Track 3-Pack (941953) デポ
setManifestid(941953, "8310295697438327235", 13281298)
-- Devil May Cry 5 - DMC2 Battle Track 3-Pack (AppID: 941954)
addappid(941954)
addappid(941954, 1, "22905c649c0a7638085caf1e214cb2baa0b318ce6e85e390cfd57b57d70acc44") -- Devil May Cry 5 - DMC2 Battle Track 3-Pack - Devil May Cry 5 - DMC2 Battle Track 3-Pack (941954) デポ
setManifestid(941954, "837912433757808297", 8524698)
-- Devil May Cry 5 - DMC3 Battle Track 3-Pack (AppID: 941955)
addappid(941955)
addappid(941955, 1, "6cd170931e9c36ade24b4efa0e76e557ccee246c7899889d20ddfc2761568f0e") -- Devil May Cry 5 - DMC3 Battle Track 3-Pack - Devil May Cry 5 - DMC3 Battle Track 3-Pack (941955) デポ
setManifestid(941955, "6069115808325012717", 29243864)
-- Devil May Cry 5 - DMC4 Battle Track 3-Pack (AppID: 941956)
addappid(941956)
addappid(941956, 1, "840af37970ff6003db44925b89968dbc86f18a4f5ea7728a1b0527ac99767ee2") -- Devil May Cry 5 - DMC4 Battle Track 3-Pack - Devil May Cry 5 - DMC4 Battle Track 3-Pack (941956) デポ
setManifestid(941956, "5302859582744244072", 19206265)
-- Devil May Cry 5 - Gerbera GP01 (AppID: 941957)
addappid(941957)
addappid(941957, 1, "36fb473794fc8ea317869c201a1e126cf16b054c69132fc5d6db7c693fa6a09b") -- Devil May Cry 5 - Gerbera GP01 - Devil May Cry 5 - Gerbera GP01 (941957) デポ
setManifestid(941957, "6916454231030537530", 91)
-- Devil May Cry 5 - Pasta Breaker (AppID: 941958)
addappid(941958)
addappid(941958, 1, "b676ca88b7d114adbabc10ecc30bab4799e64f22c33446b6a32e83b457454f8e") -- Devil May Cry 5 - Pasta Breaker - Devil May Cry 5 - Pasta Breaker (941958) デポ
setManifestid(941958, "8571966787997831230", 91)
-- Devil May Cry 5 - Sweet Surrender (AppID: 941959)
addappid(941959)
addappid(941959, 1, "57e54ceec36fa9afb6cef347ba469cfc614c41f3eeeb6cb5ba21b5531ec5b069") -- Devil May Cry 5 - Sweet Surrender - Devil May Cry 5 - Sweet Surrender (941959) デポ
setManifestid(941959, "356846819042459435", 91)
-- Devil May Cry 5 - Mega Buster (AppID: 941960)
addappid(941960)
addappid(941960, 1, "b0ce9acf93f79c995ec418457777b85f9083c219e2350d862f4b27b1c46cc03a") -- Devil May Cry 5 - Mega Buster - Devil May Cry 5 - Mega Buster (941960) デポ
setManifestid(941960, "6463853996233742067", 91)
-- Devil May Cry 5 - Cavaliere R (AppID: 941961)
addappid(941961)
addappid(941961, 1, "9ad10323310d52b75d24327b4492681b195879888808e6b7676584ee73e602a4") -- Devil May Cry 5 - Cavaliere R - Devil May Cry 5 - Cavaliere R (941961) デポ
setManifestid(941961, "8880438414751949738", 91)
-- Devil May Cry 5 - Super Character 3-Pack (AppID: 941962)
addappid(941962)
addappid(941962, 1, "fc71c9a1af83ec94a44bfe222d0bfd90e656a41f630d450c91f1e390ce8a0e27") -- Devil May Cry 5 - Super Character 3-Pack - Devil May Cry 5 - DLC_15 (941962) デポ
setManifestid(941962, "2042862104026645730", 91)
-- Devil May Cry 5 - Taunt Trio (AppID: 941963)
addappid(941963)
addappid(941963, 1, "9347ac6dd53eb62c2fd10b9d4cada1c0d75590f7b23af361635ada1adbd8576c") -- Devil May Cry 5 - Taunt Trio - Devil May Cry 5 - DLC_16 (941963) デポ
setManifestid(941963, "8463787236633176238", 91)
-- Devil May Cry 5 - V  Vergil Alt Colors (AppID: 941964)
addappid(941964)
addappid(941964, 1, "27a459ec4dbbb6c57cec3bbb0918eac697c410b77c0b6f58b6952b1e647823ff") -- Devil May Cry 5 - V  Vergil Alt Colors - Devil May Cry 5 - DLC_17 (941964) デポ
setManifestid(941964, "6178417925001500048", 91)
-- Devil May Cry 5 - Monkey Business (AppID: 941965)
addappid(941965)
addappid(941965, 1, "0859cec81d7a2d700a41952dc882dd2e6bb1ff8e3ddbb80efbe4e844859e05cb") -- Devil May Cry 5 - Monkey Business - Devil May Cry 5 - DLC_18 (941965) デポ
setManifestid(941965, "4567030356497547206", 91)
-- Devil May Cry 5 - 1 Blue Orb (AppID: 941966)
addappid(941966)
addappid(941966, 1, "e7d494f9e5d03fbe0de65683b16e9c497a14d52b382582cbb56c082cbaa9665e") -- Devil May Cry 5 - 1 Blue Orb - Devil May Cry 5 - DLC_19 (941966) デポ
setManifestid(941966, "3894647195957834299", 91)
-- Devil May Cry 5 - 3 Blue Orbs (AppID: 941967)
addappid(941967)
addappid(941967, 1, "83ca5459c1ac0c148a804381066fbe0169e4fb7164c778cb87c127d90a729986") -- Devil May Cry 5 - 3 Blue Orbs - Devil May Cry 5 - DLC_20 (941967) デポ
setManifestid(941967, "4320090065644073508", 91)
-- Devil May Cry 5 - 5 Blue Orbs (AppID: 941968)
addappid(941968)
addappid(941968, 1, "8a5969464b691846bcc55329ad079d4942db5462ef2dadca33b2542de8c060ad") -- Devil May Cry 5 - 5 Blue Orbs - Devil May Cry 5 - DLC_21 (941968) デポ
setManifestid(941968, "7938728316001059583", 91)
-- Devil May Cry 5 - 100000 Red Orbs (AppID: 941969)
addappid(941969)
addtoken(941969, "2759028962212985074")
addappid(941969, 1, "25c71ada00c2ab00725ff0a0357419440a4d8ca8d53c2c01840ccd1584b0a081") -- Devil May Cry 5 - 100000 Red Orbs - Devil May Cry 5 - 100000 Red Orbs (941969) デポ
setManifestid(941969, "1975364972596125654", 91)
-- Devil May Cry 5 - 200000 Red Orbs (AppID: 941970)
addappid(941970)
addappid(941970, 1, "9160a2957b443567516304ee567195f1d1b764b953a3a87696a475ed70bac0f4") -- Devil May Cry 5 - 200000 Red Orbs - Devil May Cry 5 - DLC_23 (941970) デポ
setManifestid(941970, "6530594450675633820", 91)
-- Devil May Cry 5 - 300000 Red Orbs (AppID: 941971)
addappid(941971)
addappid(941971, 1, "3cb4fb3259a27f93ba55d57e33095f05f37b0857d6910a295adef2f76f06264f") -- Devil May Cry 5 - 300000 Red Orbs - Devil May Cry 5 - DLC_24 (941971) デポ
setManifestid(941971, "3217701174541188638", 91)
-- Devil May Cry 5 - 500000 Red Orbs (AppID: 941972)
addappid(941972)
addappid(941972, 1, "a635a59c448abd85e82f66725f165e3ada3836a52d3085a42ae457ce2c9a0495") -- Devil May Cry 5 - 500000 Red Orbs - Devil May Cry 5 - DLC_25 (941972) デポ
setManifestid(941972, "4382130040615286187", 91)
-- Devil May Cry 5 - 1000000 Red Orbs (AppID: 941973)
addappid(941973)
addappid(941973, 1, "73e516d5614a82b39a3871c7d7ec531a64d733433d0074eaaaeb8fba88b760b4") -- Devil May Cry 5 - 1000000 Red Orbs - Devil May Cry 5 - DLC_26 (941973) デポ
setManifestid(941973, "8505788485278530046", 91)
-- Devil May Cry 5 - Wallpaper (AppID: 945600)
addappid(945600)
addtoken(945600, "11164922436573908868")
addappid(945600, 1, "75c3bd851a87a16db2f06576a3c2fe55a5a46fadd905763369ac503d9f4d6b34") -- Devil May Cry 5 - Wallpaper - Devil May Cry 5 - Wallpaper (945600) デポ
setManifestid(945600, "1049804611294232219", 2010171)
-- Devil May Cry 5 - Playable Character Vergil (AppID: 1432640)
addappid(1432640)
addappid(1432640, 1, "ad27e4adecfeebddb59585bb0cc782ff19110b37e71727db16773fc7f163c5f2") -- Devil May Cry 5 - Playable Character Vergil - DLC1 (1432640) デポ
setManifestid(1432640, "5156559174384676617", 183)
-- Devil May Cry 5 - Vergil Battle Track 4-Pack (AppID: 1432641)
addappid(1432641)
addappid(1432641, 1, "cf7ccae95bbb188fb00c15fff94110f47da8b1a81568b97ac048d8b08d8ff565") -- Devil May Cry 5 - Vergil Battle Track 4-Pack - DLC2 (1432641) デポ
setManifestid(1432641, "4622666309481266876", 241)
-- Devil May Cry 5 - Super Vergil Unlock (AppID: 1432642)
addappid(1432642)
addappid(1432642, 1, "b934aa77981e2ec0ba78938cee0a6784c0f3d6e90275ebaed59103671c8af5c8") -- Devil May Cry 5 - Super Vergil Unlock - DLC3 (1432642) デポ
setManifestid(1432642, "3752668043537101024", 186)
-- Devil May Cry 5 - Vergil EX Provocation (AppID: 1432643)
addappid(1432643)
addappid(1432643, 1, "d766c1b6bf790cbc12456eee09056a8f6ca4022fac09312f11b98a5a5ad0faf4") -- Devil May Cry 5 - Vergil EX Provocation - DLC4 (1432643) デポ
setManifestid(1432643, "6950015429532708433", 186)