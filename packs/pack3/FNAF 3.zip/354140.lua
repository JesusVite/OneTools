-- 354140's Lua and Manifest Created by Morrenus
-- Five Nights at Freddy's 3
-- Created: September 29, 2025 at 12:34:28 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(354140) -- Five Nights at Freddy's 3
-- MAIN APP DEPOTS
addappid(354141, 1, "ab90f669c8c840ed1677b657358f1ea2469927005c05b738dc6f1a08c8ae4d7e") -- Five Nights at Freddy's 3 Content
setManifestid(354141, "5435764134113512896", 116634069)