-- 389730's Lua and Manifest Created by Morrenus
-- TEKKEN 7
-- Created: September 30, 2025 at 22:10:02 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 29
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(389730) -- TEKKEN 7
-- MAIN APP DEPOTS
addappid(389731, 1, "ced260a7f27dd73a1bdb16c642549470d25ee659c70bc35dc9879e23d38e811c") -- TEKKEN 7 Content
setManifestid(389731, "1653672533371481747", 86942923011)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(580020) -- TEKKEN 7 - Season Pass
addappid(592370) -- TEKKEN 7 - Eliza Pre-order Bonus - DLC
addtoken(592370, "7629745928377525948")
addappid(592371) -- TEKKEN 7 - Metallic costumes Season Pass Bonus - DLC
addtoken(592371, "18402440993168939028")
addappid(592372) -- TEKKEN 7 DLC 1 Ultimate TEKKEN BOWL  Additional Costumes
addappid(592373) -- TEKKEN 7 DLC 2 Geese Howard Pack
addappid(592374) -- TEKKEN 7 DLC 3 Noctis Lucis Caelum Pack
addappid(651430) -- TEKKEN 7 - TAIKO NO TATSUJIN Pack
addappid(682560) -- TEKKEN 7 - Character Panel
addappid(878460) -- TEKKEN 7 - DLC4 Anna Williams
addappid(878461) -- TEKKEN 7 - DLC5 Lei Wulong
addappid(878462) -- TEKKEN 7 - Craig Marduk
addappid(878463) -- TEKKEN 7 - Armor King
addappid(878464) -- TEKKEN 7 - DLC8 Julia Chang
addappid(878465) -- TEKKEN 7 - DLC9 Negan
addappid(878466) -- TEKKEN 7 - Bonus Character Customization Items
addtoken(878466, "5682005606814451290")
addappid(878467) -- TEKKEN 7 - Season Pass 2
addappid(1114550) -- TEKKEN 7 - Season Pass 3
addappid(1114560) -- TEKKEN 7 - SP3 Bonus Character Customization Items
addappid(1114561) -- TEKKEN 7 - DLC10 Zafina
addappid(1162600) -- TEKKEN 7 - DLC11 Ganryu
addtoken(1162600, "16665772109696247537")
addappid(1162601) -- TEKKEN 7 - DLC12 Leroy Smith
addappid(1162602) -- TEKKEN 7 - DLC13 Frame Data Display
addappid(1236500) -- TEKKEN 7 - DLC14 Fahkumram
addappid(1236501) -- TEKKEN 7 - DLC15 CAVE OF ENLIGHTENMENT
addappid(1289450) -- TEKKEN 7 - Season Pass 4
addappid(1289451) -- TEKKEN 7 - DLC16 Kunimitsu
addappid(1289452) -- TEKKEN 7 - DLC17 Vermilion Gates
addappid(1289453) -- TEKKEN 7 - DLC18 Lidia Sobieska
addappid(1289454) -- TEKKEN 7 - DLC19 Island Paradise