-- 57300's Lua and Manifest Created by Morrenus
-- Amnesia: The Dark Descent
-- Created: September 28, 2025 at 22:18:50 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 5
-- Total DLCs: 0 (1 excluded)
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(57300, 1, "1ed10bd9c834efd5be56ce2f43f993136b642f11255b95272a59e90a30cd376f") -- Amnesia: The Dark Descent
-- MAIN APP DEPOTS
addappid(57301, 1, "287ec5e230f11e2f8a67433979f31da236fb1e7b579001e6003c1fb4366ecdc9") -- AmnesiaTDDData
setManifestid(57301, "8176595565127463406", 2470990313)
addappid(57303, 1, "ce1096b118e5aff8343dd9857272297089fd05e0bd45256fe20a99e23752e575") -- AmnesiaTDDMacOS
setManifestid(57303, "7774437381089252368", 56373921)
addappid(57302, 1, "9aac14afdc112490cff7559885648ddab96c2ac65eb51b5c0f0858117ff576dd") -- AmnesiaTDDWindows
setManifestid(57302, "1043555087927484063", 66636327)
addappid(57304, 1, "23b492b4a4acf4b87453c4791ab22324d8bdba0a9a5a21f67dab42d2056639e8") -- AmnesiaTDDLinux
setManifestid(57304, "4923969545681340455", 115025638)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Amnesia Accessed Content (AppID: 98002) - missing depot keys
-- addappid(98002)