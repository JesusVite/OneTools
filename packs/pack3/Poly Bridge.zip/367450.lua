-- 367450's Lua and Manifest Created by Morrenus
-- Poly Bridge
-- Created: September 30, 2025 at 07:26:47 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 5
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(367450, 1, "db284e990493c81a8718c80e988cb165e376d959f646cc004219cdb4d7244075") -- Poly Bridge
-- MAIN APP DEPOTS
addappid(367451, 1, "d665d606792ae4631a504bd59f59310fffb87490652e9b149616eda8ad5962ba") -- Poly Bridge Windows
setManifestid(367451, "3168549286285070087", 223243078)
addappid(367452, 1, "1d911373e5f75e7fe50cf3e2708aab9380d1565dc3e7fc9bacb9339cc042dec6") -- Poly Bridge Mac
setManifestid(367452, "5300884783176432417", 232849566)
addappid(367453, 1, "03f1099f465d40ba0296be94392f13b6a696331a12f878d8a4931efb7a88397d") -- Poly Bridge Linux
setManifestid(367453, "1283089157963056478", 254062310)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
setManifestid(229004, "5220958916987797232", 70000464)