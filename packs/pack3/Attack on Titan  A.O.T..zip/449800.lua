-- 449800's Lua and Manifest Created by Morrenus
-- Attack on Titan / A.O.T. Wings of Freedom
-- Created: September 28, 2025 at 23:33:08 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 30
-- Total DLCs: 13
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(449800) -- Attack on Titan / A.O.T. Wings of Freedom
-- MAIN APP DEPOTS
addappid(449801, 1, "ab0081f3cb3f4fff6990b5447e954d2d7374624ddb3f57bd2e25cced981ada11") -- Project AT EUNA
setManifestid(449801, "4420363297810017263", 18595361082)
addappid(449802, 1, "e0fc7c47bed2e0d15d745266f59ad154b394482be3cf1f491855223a1f61c04f") -- Project AT TCH
setManifestid(449802, "4953409040098611276", 18049308010)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Mikasa Costume - Summer Festival (AppID: 486000)
addappid(486000)
addappid(486000, 1, "94a6b5a8f468e3d2e2bdb17a83eb72d6c6018fd6b3d592c63e5c0180abc723b0") -- Mikasa Costume - Summer Festival - Mikasa Costume - Summer Festival (486000) 個のデポ
setManifestid(486000, "9007211594557052337", 22639648)
addappid(449803, 1, "42c1fba67b8be1fa33c6ab19f38e49256026273b204167f0db203c52c00a0e3f") -- Mikasa Costume - Summer Festival - Mikasa Costume - Summer Festival(TCH)
setManifestid(449803, "1208768453914313798", 22639584)
-- Eren  Levi Costume - Clean-up (AppID: 486001)
addappid(486001)
addappid(486001, 1, "4fb54a8e990bc5fd2bbed9e06f3a2bb3eb86a0813906357d34738882b75ec25f") -- Eren  Levi Costume - Clean-up - Eren & Levi Costume - Clean-up (486001) 個のデポ
setManifestid(486001, "1275293376775043893", 240)
addappid(449804, 1, "dd13196a0b008ddd146321a8904ee877ac70781bd0c959426bf37aa961c74800") -- Eren  Levi Costume - Clean-up - Eren & Levi Costume - Clean-up(TCH)
setManifestid(449804, "3052165542837096299", 240)
-- Costume Set - Summer Festival (AppID: 486002)
addappid(486002)
addappid(486002, 1, "8022fa4b5b618880dc414dd0b75336164a5b7a7d82987c6ad94bfef7645edf71") -- Costume Set - Summer Festival - Costume Set - Summer Festival (486002) 個のデポ
setManifestid(486002, "200958735697651783", 68977280)
addappid(449805, 1, "5c905e62017ffb1ff635eab91ed23247f49213698ebe18d0a5aaad8a017d70b3") -- Costume Set - Summer Festival - Costume Set - Summer Festival(TCH)
setManifestid(449805, "4028548089369368982", 68977088)
-- Weapon - Summer Festival (AppID: 486003)
addappid(486003)
addappid(486003, 1, "e994fbd1ecb70928e3ad8731c11255f121d536004a9dbca3f28b564c3153d921") -- Weapon - Summer Festival - Weapon - Summer Festival (486003) 個のデポ
setManifestid(486003, "7359282320979548080", 22752576)
addappid(449806, 1, "a66937978e324cf76fae9fd3437b66a7d335eb64fb46a7f2bd6566b5685c80f2") -- Weapon - Summer Festival - Weapon - Summer Festival(TCH)
setManifestid(449806, "2564183602376932826", 22749392)
-- Episode 1 (AppID: 486004)
addappid(486004)
addappid(486004, 1, "a4aa1dc3d00033e7a73b190ff11f385308560fa037870ec8f4d01a9b68cbd4c9") -- Episode 1 - Episode 1 (486004) 個のデポ
setManifestid(486004, "2921701076291720454", 837920)
addappid(449807, 1, "8e17224f010484e34036e72aa48d55a9f27a6d123f0fcaaaad38346e5bf5f33e") -- Episode 1 - Episode 1(TCH)
setManifestid(449807, "1243629838416422832", 789616)
-- Episode 2 (AppID: 486005)
addappid(486005)
addappid(486005, 1, "e2a41bbb5d2201afdfd186b51c8755e62539b1145c0a153b1bc3f9a1e7043a5e") -- Episode 2 - Episode 2 (486005) 個のデポ
setManifestid(486005, "2666029590588140278", 829520)
addappid(449808, 1, "9ccae0a763189a1f1ffcb87f830e689eeba8a449cbf533a4535c49dffc073d07") -- Episode 2 - Episode 2(TCH)
setManifestid(449808, "4635003092317768253", 773840)
-- Episode 3 (AppID: 486006)
addappid(486006)
addappid(486006, 1, "348b4180be046779779f8b4410da9f1bd8d94552d4bf62dbc05151934d2e20d6") -- Episode 3 - Episode 3 (486006) 個のデポ
setManifestid(486006, "1192836355006378505", 837168)
addappid(449809, 1, "5fa843afffd656ee5f0ca245caa6147260642cd7b255213908a129a1ba871ea1") -- Episode 3 - Episode 3(TCH)
setManifestid(449809, "76982484519280557", 772656)
-- Costume Set - Halloween (AppID: 486007)
addappid(486007)
addappid(486007, 1, "0ab73beeb4918b434dd9b80597e1e499c0797bfc90c0139f2e39072a0d282fc6") -- Costume Set - Halloween - Costume Set - Halloween (486007) 個のデポ
setManifestid(486007, "6532905553484444020", 93764096)
addappid(486013, 1, "2039cf72a2e2a40e23a7625f6e850ab810ed55f0aaeba72be59ff0e08a176b04") -- Costume Set - Halloween - Costume Set - Halloween(TCH)
setManifestid(486013, "1610417325692114952", 93763904)
-- Weapon - Halloween (AppID: 486008)
addappid(486008)
addappid(486008, 1, "fe7fbf21ad9cbea17d5804c2f484df69add7aba99c51ecbc3342cdb1f26ebb08") -- Weapon - Halloween - Weapon - Halloween (486008) 個のデポ
setManifestid(486008, "5448578991900152025", 22870816)
addappid(486014, 1, "d40da15737c456446b695dee52b3c4994abd407e4485dfc9cc86e847b794fdea") -- Weapon - Halloween - Weapon - Halloween(TCH)
setManifestid(486014, "884947839248967465", 22867376)
-- Costume Set - Christmas (AppID: 486009)
addappid(486009)
addappid(486009, 1, "0e699eabb4b073c61048e687eabe777eca10d8f68fb2496c7a8735c49e5211cd") -- Costume Set - Christmas - Costume Set - Christmas (486009) 個のデポ
setManifestid(486009, "1905129270719630616", 94447120)
addappid(486015, 1, "f364038ad6f28f13442baeb2a5be51930c6e08240f605b72026fb9150420d414") -- Costume Set - Christmas - Costume Set - Christmas(TCH)
setManifestid(486015, "507695152872522690", 94446928)
-- Weapon - Christmas (AppID: 486010)
addappid(486010)
addappid(486010, 1, "4e92301503ae62bca8bdc4395cb66963f328549b7a87759eba4c08b22f23dc88") -- Weapon - Christmas - Weapon - Christmas (486010) 個のデポ
setManifestid(486010, "4341821369043029620", 21352736)
addappid(486016, 1, "d116291104ca44db14ecd2f6ca6ca925ee35c8ec00f89b8238ed0bfac2a934f8") -- Weapon - Christmas - Weapon - Christmas(TCH)
setManifestid(486016, "214987980776334294", 21350048)
-- Costume Set - Japanese New Year (AppID: 486011)
addappid(486011)
addappid(486011, 1, "f47eb9b7769a5e01c60cfd1bd12cf20784194b5aad43fd2fbb6a53df538d253d") -- Costume Set - Japanese New Year - Costume Set - Japanese New Year (486011) 個のデポ
setManifestid(486011, "2729902102527213806", 92992208)
addappid(486017, 1, "e75e08718d5548d67e8f9c38fe1db77b05b162ab5c0abae9a8d8950428ca7bf4") -- Costume Set - Japanese New Year - Costume Set - Japanese New Year(TCH)
setManifestid(486017, "8483154906385183130", 92991952)
-- Weapon - Japanese New Year (AppID: 486012)
addappid(486012)
addappid(486012, 1, "e1b348c2420e0e799d7dc5810cbb104fc500218590e42436b983632049055758") -- Weapon - Japanese New Year - Weapon - Japanese New Year (486012) 個のデポ
setManifestid(486012, "3456499183443244296", 24462208)
addappid(486018, 1, "753c0025dd5cc99a241c219df8aa87616c28c9d57c96dc345ca02c1b4ca12b96") -- Weapon - Japanese New Year - Weapon - Japanese New Year(TCH)
setManifestid(486018, "5764146880332025446", 24459632)