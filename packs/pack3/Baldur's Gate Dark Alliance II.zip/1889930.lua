-- 1889930's Lua and Manifest Created by Morrenus
-- Baldur's Gate: Dark Alliance II
-- Created: December 01, 2025 at 08:55:58 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1889930) -- Baldur's Gate: Dark Alliance II
-- MAIN APP DEPOTS
addappid(1889931, 1, "c271a57d12525930ad8de02c5de1699b688dd35e1558bf77d95c147389ec6ba3") -- Depot 1889931
setManifestid(1889931, "6789340646862609413", 4628631030)
addappid(1889933, 1, "e7245cbf8f08056e6b0c2bf56cbc1dc299d3cfdda99b238feca6ebbc7cee0657") -- Depot 1889933
setManifestid(1889933, "3960934968086778100", 4626326263)