-- 671510's Lua and Manifest Created by Morrenus
-- Desolate
-- Created: September 29, 2025 at 07:28:07 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 13
-- Total DLCs: 1
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(671510) -- Desolate
-- MAIN APP DEPOTS
addappid(671511, 1, "25031245c895e3a3124c5b86ccc77a8a30045ff1701d203232e659cc7ebf4dc0") -- Desolate Content En
setManifestid(671511, "3373314222954487166", 17791754646)
addappid(671512, 1, "e66e31f460c1a1390fa382d12fd578cbd5045f037b114aa00b5c35550110530f") -- Desolate Content Ru
setManifestid(671512, "754747788672614278", 32)
addappid(671513, 1, "d7f3edaae74ea8b2ded4ad24097400ca3ab0ee74f91e99d7f84ac5f0c461a595") -- Desolate Content Cn
setManifestid(671513, "373879150285706005", 37)
addappid(671514, 1, "2337d2d166a2c713177f8797b58892e412279f92bf6f28611045dbfdb4531b45") -- Desolate Content Kr
setManifestid(671514, "490252179005926509", 32)
addappid(671515, 1, "9f41d84f75578ba1ce7279be29e95754f63206ba753f6f7337d64ef8030e372a") -- Desolate Content Ja
setManifestid(671515, "675633920339902143", 32)
addappid(671516, 1, "db0eb922b322591c9465e491a33e8d17b14339dac56810c9c45b4ad200de74fa") -- Desolate Content Fr
setManifestid(671516, "2717402347821849222", 32)
addappid(671517, 1, "02b9dfe5c6af6ffa5fcd9f5b048e412e594e8b580409f3590178f262123a706c") -- Desolate Content Es
setManifestid(671517, "2255003990826036417", 32)
addappid(671518, 1, "01ff5b3cb14be100fb15e88736c50cf232279033e42ac4721eaa6a3e0959dab3") -- Desolate Content De
setManifestid(671518, "489902818439089255", 32)
addappid(671519, 1, "9596701371333ef450f68648db78eb3c1b4e3f0fee08aed15c12d4e31024fcc9") -- Desolate Content Pt
setManifestid(671519, "1177229041203299246", 74)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- DESOLATE - Original Soundtrack (AppID: 805060)
addappid(805060)
addappid(805060, 1, "b41341c745b92a0661e161f12a068cc87743f99bdd1166a770dead66cf81fba2") -- DESOLATE - Original Soundtrack - DESOLATE - Original Soundtrack Depot
setManifestid(805060, "7727290428716772189", 176953513)