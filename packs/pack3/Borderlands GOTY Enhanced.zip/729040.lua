-- 729040's Lua and Manifest Created by Morrenus
-- Borderlands GOTY Enhanced
-- Created: September 29, 2025 at 01:57:39 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 5
-- Total DLCs: 0
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(729040) -- Borderlands GOTY Enhanced
-- MAIN APP DEPOTS
addappid(729041, 1, "6bf645f76a001bb548c0f52d99fb5a7f5c7130c9a7ed3d6518318c0bdea77f8d") -- Mopane Content
setManifestid(729041, "3930773085502141992", 20011064108)
-- SHARED DEPOTS (from other apps)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
setManifestid(229002, "7260605429366465749", 50450161)