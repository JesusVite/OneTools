-- 506610's Lua and Manifest Created by Morrenus
-- Five Nights at Freddy's: Sister Location
-- Created: September 29, 2025 at 12:34:51 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(506610) -- Five Nights at Freddy's: Sister Location
-- MAIN APP DEPOTS
addappid(506611, 1, "a9afd962f2b3b13615d00940a036fe77bf9bf5c0091de7c9474ac584c51d818f") -- Five Nights at Freddy's: Sister Location Content
setManifestid(506611, "749438696463073559", 950556728)