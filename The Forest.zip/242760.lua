-- 242760's Lua and Manifest Created by Morrenus
-- The Forest
-- Created: October 05, 2025 at 19:28:21 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(242760) -- The Forest
-- MAIN APP DEPOTS
addappid(242761, 1, "786dfb9db41be351c888b4a930d5295dfe6c8c4bbc4e442f0e1ced301c4d24df") -- The Forest Content
setManifestid(242761, "1816573600225453267", 5950220689)