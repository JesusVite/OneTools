-- 1130620's Lua and Manifest Created by Morrenus
-- Aka Manto | 赤マント
-- Created: September 28, 2025 at 21:54:26 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1130620) -- Aka Manto | 赤マント
-- MAIN APP DEPOTS
addappid(1130621, 1, "413cc73b0863f91a3e1e44733da9846746b58bc1d614d71d418b920ad25cb4e1") -- Aka Manto | 赤マント Content
setManifestid(1130621, "2733476488770922466", 3112559003)