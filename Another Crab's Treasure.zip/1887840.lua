-- 1887840's Lua and Manifest Created by Morrenus
-- Another Crab's Treasure
-- Created: October 10, 2025 at 07:02:36 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1887840) -- Another Crab's Treasure
-- MAIN APP DEPOTS
addappid(1887841, 1, "19257cfc9a0b90cd9687a6893dbd234efcbb0cab05776a8180a2a49a271cccad") -- Depot 1887841
setManifestid(1887841, "6580916792180647645", 8297545355)